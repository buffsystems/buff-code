// A pair's daily use (#909, #915): the gateway counts the bytes of every pair «phone — install or
// machine» per UTC day against a limit of the admin's settings, and tells each side on its control
// subject (relay.ctrl.<peer>):
//   { type: 'quota', limit, day }                — on connecting: the limit, before any traffic;
//   { type: 'usage', with, bytes, limit, day }   — on connecting, and at each percent of the limit;
//   { type: 'limit', code: 'pair-quota', with }  — the pair ran out: the sender is cut off till the day ends.
// The book keeps what was told, per other side; both a phone and an install read their pairs from it.

export type UsageNotice =
  | { type: 'quota'; limit: number; day: string }
  | { type: 'usage'; with: string; bytes: number; limit: number; day: string }
  | { type: 'limit'; code: 'pair-quota'; with: string }

/** A pair's use today: bytes of the limit; `exhausted` — cut off until the day ends. */
export interface PairUsage {
  bytes: number
  limit: number
  /** The UTC day, YYYY-MM-DD; the use resets at its end (resetsAt). */
  day: string
  exhausted: boolean
}

const count = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v) && v >= 0
const text = (v: unknown): v is string => typeof v === 'string' && v.length > 0

export function parseUsageNotice(m: unknown): UsageNotice | null {
  if (typeof m !== 'object' || m === null) return null
  const n = m as Record<string, unknown>
  if (n.type === 'quota' && count(n.limit) && text(n.day))
    return { type: 'quota', limit: n.limit, day: n.day }
  if (n.type === 'usage' && text(n.with) && count(n.bytes) && count(n.limit) && text(n.day))
    return { type: 'usage', with: n.with, bytes: n.bytes, limit: n.limit, day: n.day }
  if (n.type === 'limit' && n.code === 'pair-quota' && text(n.with))
    return { type: 'limit', code: 'pair-quota', with: n.with }
  return null
}

/** When the use of `day` starts over: the next midnight UTC, epoch ms. */
export function resetsAt(day: string): number {
  const [y, m, d] = day.split('-').map(Number)
  return Date.UTC(y!, m! - 1, d! + 1)
}

/** What a peer was told of its pairs' use; a notice of a new day starts it over. */
export function usageBook() {
  let quota: { limit: number; day: string } | null = null
  const used = new Map<string, PairUsage>()
  const startDay = (day: string, limit: number) => {
    if (quota?.day === day) return
    used.clear()
    quota = { limit, day }
  }
  return {
    apply(n: UsageNotice): void {
      if (n.type === 'quota') return startDay(n.day, n.limit)
      if (n.type === 'usage') {
        startDay(n.day, n.limit)
        quota = { limit: n.limit, day: n.day }
        used.set(n.with, {
          bytes: n.bytes,
          limit: n.limit,
          day: n.day,
          exhausted: used.get(n.with)?.exhausted ?? false,
        })
        return
      }
      if (!quota) return
      const was = used.get(n.with) ?? {
        bytes: quota.limit,
        limit: quota.limit,
        day: quota.day,
        exhausted: false,
      }
      used.set(n.with, { ...was, exhausted: true })
    },
    /** The pair with `other`: null while the gateway told nothing yet. */
    of(other: string): PairUsage | null {
      if (!quota) return null
      return used.get(other) ?? { bytes: 0, limit: quota.limit, day: quota.day, exhausted: false }
    },
  }
}

export type UsageBook = ReturnType<typeof usageBook>
