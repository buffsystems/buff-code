# Buff mobile

Мобильное приложение Buff (iOS / Android) и общий протокол связи телефона с установками
Buff — эпик autonomous-dev/cloud-front#628.

| Каталог             | Что это                                                                                                |
| ------------------- | ------------------------------------------------------------------------------------------------------ |
| `apps/buff`         | приложение Expo (#641): как запустить на телефоне — в его README                                       |
| `packages/protocol` | `@buff/mobile-protocol` — сквозное шифрование, рукопожатие, сопряжение, имена subject'ов ретранслятора |

## Сборочный Mac для iOS

iOS собирается и проверяется в симуляторе на Mac с GitLab Runner (shell-исполнитель, тег `macos`):
джобы `ios:build` и `ios:sim-check`. Служебный Mac с нуля готовит один скрипт — Xcode (ставится
заранее из App Store), среда симулятора iOS, Homebrew, node 22, CocoaPods, Java, Maestro, режим
без сна и раннер как сервис:

```sh
RUNNER_TOKEN=glrt-… bash scripts/mac-builder-setup.sh
```

Токен — у раннера проекта с тегом `macos` (Settings → CI/CD → Runners). Как запускать джобы и что
они проверяют — [docs/ios-build.md](docs/ios-build.md).
