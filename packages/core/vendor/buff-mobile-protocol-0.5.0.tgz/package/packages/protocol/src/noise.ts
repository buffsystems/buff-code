// Noise_KK_25519_ChaChaPoly_SHA256 (Noise rev. 34), the handshake core. Both sides already know each
// other's static key from pairing, so KK gives mutual authentication, fresh ephemerals per
// connection (forward secrecy) and a handshake hash binding both statics. Checked byte for byte
// against the cacophony test vector. Only the two handshake messages and Split() live here — the
// transport after Split is the envelope (envelope.ts).
//
//   -> s
//   <- s
//   ...
//   -> e, es, ss
//   <- e, ee, se

import { chacha20poly1305 } from '@noble/ciphers/chacha.js'
import { x25519 } from '@noble/curves/ed25519.js'
import { hmac } from '@noble/hashes/hmac.js'
import { sha256 } from '@noble/hashes/sha2.js'
import { concat, utf8 } from './encoding.ts'
import { fail } from './errors.ts'

const PROTOCOL_NAME = utf8('Noise_KK_25519_ChaChaPoly_SHA256')
const KEY_BYTES = 32

export interface StaticKeys {
  readonly secret: Uint8Array
  readonly public: Uint8Array
}

export interface KkParams {
  readonly prologue: Uint8Array
  readonly local: StaticKeys
  readonly remotePublic: Uint8Array
  readonly ephemeralSecret: Uint8Array
}

export interface SplitKeys {
  /** Initiator → responder. */
  readonly k1: Uint8Array
  /** Responder → initiator. */
  readonly k2: Uint8Array
  readonly handshakeHash: Uint8Array
}

export interface Symmetric {
  ck: Uint8Array
  h: Uint8Array
  k: Uint8Array | null
  n: number
}

/** Noise ChaChaPoly nonce: 32 zero bits then a 64-bit little-endian counter. */
export function noiseEncrypt(
  k: Uint8Array,
  n: number,
  ad: Uint8Array,
  plaintext: Uint8Array,
): Uint8Array {
  return chacha20poly1305(k, noiseNonce(n), ad).encrypt(plaintext)
}

export function noiseDecrypt(
  k: Uint8Array,
  n: number,
  ad: Uint8Array,
  ciphertext: Uint8Array,
): Uint8Array {
  try {
    return chacha20poly1305(k, noiseNonce(n), ad).decrypt(ciphertext)
  } catch {
    return fail('decrypt-failed', 'handshake message did not authenticate')
  }
}

function noiseNonce(n: number): Uint8Array {
  const nonce = new Uint8Array(12)
  new DataView(nonce.buffer).setBigUint64(4, BigInt(n), true)
  return nonce
}

function hkdf2(ck: Uint8Array, ikm: Uint8Array): [Uint8Array, Uint8Array] {
  const temp = hmac(sha256, ck, ikm)
  const out1 = hmac(sha256, temp, Uint8Array.of(1))
  return [out1, hmac(sha256, temp, concat(out1, Uint8Array.of(2)))]
}

function dh(secret: Uint8Array, publicKey: Uint8Array): Uint8Array {
  try {
    return x25519.getSharedSecret(secret, publicKey)
  } catch {
    return fail('bad-message', 'invalid X25519 public key')
  }
}

function initialize(
  prologue: Uint8Array,
  initiatorStatic: Uint8Array,
  responderStatic: Uint8Array,
): Symmetric {
  const s: Symmetric = { ck: PROTOCOL_NAME, h: PROTOCOL_NAME, k: null, n: 0 }
  mixHash(s, prologue)
  mixHash(s, initiatorStatic)
  mixHash(s, responderStatic)
  return s
}

function mixHash(s: Symmetric, data: Uint8Array): void {
  s.h = sha256(concat(s.h, data))
}

function mixKey(s: Symmetric, ikm: Uint8Array): void {
  const [ck, k] = hkdf2(s.ck, ikm)
  s.ck = ck
  s.k = k
  s.n = 0
}

function encryptAndHash(s: Symmetric, plaintext: Uint8Array): Uint8Array {
  const ct = s.k ? noiseEncrypt(s.k, s.n++, s.h, plaintext) : plaintext
  mixHash(s, ct)
  return ct
}

function decryptAndHash(s: Symmetric, ciphertext: Uint8Array): Uint8Array {
  const pt = s.k ? noiseDecrypt(s.k, s.n++, s.h, ciphertext) : ciphertext
  mixHash(s, ciphertext)
  return pt
}

function split(s: Symmetric): SplitKeys {
  const [k1, k2] = hkdf2(s.ck, new Uint8Array(0))
  return { k1, k2, handshakeHash: s.h }
}

function ephemeral(params: KkParams): StaticKeys {
  return { secret: params.ephemeralSecret, public: x25519.getPublicKey(params.ephemeralSecret) }
}

/** Initiator, message 1. Keep the returned state until message 2 arrives. */
export function kkWriteMessage1(
  params: KkParams,
  payload: Uint8Array,
): { message: Uint8Array; state: KkInitiatorState } {
  const s = initialize(params.prologue, params.local.public, params.remotePublic)
  const e = ephemeral(params)
  mixHash(s, e.public)
  mixKey(s, dh(e.secret, params.remotePublic))
  mixKey(s, dh(params.local.secret, params.remotePublic))
  const message = concat(e.public, encryptAndHash(s, payload))
  return { message, state: { symmetric: s, params, e } }
}

export interface KkInitiatorState {
  readonly symmetric: Symmetric
  readonly params: KkParams
  readonly e: StaticKeys
}

/** Responder: read message 1, write message 2. The payload of message 2 may depend on message 1's. */
export function kkRespond(
  params: KkParams,
  message1: Uint8Array,
  reply: (payload1: Uint8Array) => Uint8Array,
): { payload: Uint8Array; message: Uint8Array; keys: SplitKeys } {
  if (message1.length < KEY_BYTES + 16) fail('bad-message', 'handshake message 1 too short')
  const s = initialize(params.prologue, params.remotePublic, params.local.public)
  const re = message1.subarray(0, KEY_BYTES)
  mixHash(s, re)
  mixKey(s, dh(params.local.secret, re))
  mixKey(s, dh(params.local.secret, params.remotePublic))
  const payload = decryptAndHash(s, message1.subarray(KEY_BYTES))
  const e = ephemeral(params)
  mixHash(s, e.public)
  mixKey(s, dh(e.secret, re))
  mixKey(s, dh(e.secret, params.remotePublic))
  const message = concat(e.public, encryptAndHash(s, reply(payload)))
  return { payload, message, keys: split(s) }
}

/** Initiator, message 2. */
export function kkReadMessage2(
  state: KkInitiatorState,
  message2: Uint8Array,
): { payload: Uint8Array; keys: SplitKeys } {
  if (message2.length < KEY_BYTES + 16) fail('bad-message', 'handshake message 2 too short')
  const s: Symmetric = { ...state.symmetric }
  const re = message2.subarray(0, KEY_BYTES)
  mixHash(s, re)
  mixKey(s, dh(state.e.secret, re))
  mixKey(s, dh(state.params.local.secret, re))
  const payload = decryptAndHash(s, message2.subarray(KEY_BYTES))
  return { payload, keys: split(s) }
}
