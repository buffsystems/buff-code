// Pairing: one-time introduction of a phone (the claimer) to an install / Buff Code machine / SaaS
// gateway (the offerer), so that each side ends up with the other's peer card. The gateway brokers
// the messages but must not be able to substitute either card:
//
//  • QR:   link + 128-bit secret in the URL fragment. Both cards travel sealed under a key derived
//          from the secret (HKDF), which the gateway never sees → substitution is impossible.
//  • Code: link without a secret + 8 Crockford-base32 characters (40 bits) shown on the computer.
//          Cards travel sealed under Argon2id(code); the gateway counts claims (≤ 5) and expires the
//          offer. A gateway that brute-forces the code offline could still swap cards, so the code
//          path ends with a 6-digit SAS confirmed by a human on the computer. The SAS mixes a
//          commit–reveal pair of nonces (the claimer commits before seeing the offerer's nonce and
//          reveals after), so a man in the middle cannot grind a matching SAS: one guess, 10⁻⁶.
//
// Message flow (subjects in subjects.ts, bodies in gateway.ts; the sender is the subject's last token):
//   offerer  → relay.cmd.offer    {offerId, kind, sealed(offer body), expiresAt}
//   claimer  → relay.cmd.claim    {offerId, sealed(claim body incl. commit)}      ← gateway counts it
//   offerer  ↩ (via gateway)      {sealed(offer body), nonce}                      → reply to claimer
//   claimer  → relay.cmd.reveal   {offerId, reveal}                               (code only)
//   both show the SAS; human confirms on the computer
//   offerer  → relay.cmd.confirm  {offerId, claimer}                               → pair recorded

import { xchacha20poly1305 } from '@noble/ciphers/chacha.js'
import { argon2idAsync } from '@noble/hashes/argon2.js'
import { hkdf } from '@noble/hashes/hkdf.js'
import { sha256 } from '@noble/hashes/sha2.js'
import {
  b64u,
  concat,
  decodeJson,
  encodeJson,
  equalBytes,
  fromB64u,
  fromB64uLength,
  readU32be,
  utf8,
} from './encoding.ts'
import { fail } from './errors.ts'
import { isPeerId, type PeerCard, type PeerKeys, verifyPeerCard } from './identity.ts'
import { type Random, systemRandom } from './random.ts'

export const QR_OFFER_TTL_MS = 5 * 60 * 1000
export const CODE_OFFER_TTL_MS = 15 * 60 * 1000
export const MAX_CODE_ATTEMPTS = 5
/**
 * Argon2id for the code path: 1 MiB, 2 passes. The phone runs it in pure JS on Hermes (no JIT,
 * ~1.4 ms per KiB·pass measured on Android 14): OWASP's 19 MiB took 61 s there. A code lives 15
 * minutes with 5 online tries; an offline 2^40 search at 1 MiB still costs GPU-months per
 * offer — and a cracked code buys a man in the middle nothing past the SAS.
 */
export const CODE_KDF = { t: 2, m: 1024, p: 1 } as const

export type OfferKind = 'qr' | 'code'
export type PeerKind = 'device' | 'install' | 'machine' | 'saas'

export type PairingSecret =
  | { readonly kind: 'qr'; readonly offerId: string; readonly secret: Uint8Array }
  | { readonly kind: 'code'; readonly offerId: string; readonly code: string }

/** The offerer's sealed self-description. */
export interface OfferBody {
  readonly card: PeerCard
  readonly kind: Exclude<PeerKind, 'device'>
  /** Install name / machine hostname, shown on the phone. */
  readonly display: string
}

/** The claimer's sealed self-description; `commit` is present on the code path. */
export interface ClaimBody {
  readonly card: PeerCard
  /** Phone model, shown in the device list. */
  readonly display: string
  readonly commit?: string
}

export interface PairOfferMessage {
  readonly offerId: string
  readonly kind: OfferKind
  readonly sealed: string
  readonly expiresAt: number
}

export interface PairClaimMessage {
  readonly offerId: string
  readonly sealed: string
}

export interface PairClaimReply {
  readonly sealed: string
  readonly nonce?: string
}

export interface PairRevealMessage {
  readonly offerId: string
  readonly reveal: string
}

export interface PairConfirmMessage {
  readonly offerId: string
  readonly claimer: string
}

export interface PairRevokeMessage {
  readonly pairId: string
}

const CROCKFORD = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'
const TOKEN = /^[A-Za-z0-9_-]{22}$/
const GATEWAY = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*(:\d{1,5})?$/

export function createOffer(kind: OfferKind, random: Random = systemRandom): PairingSecret {
  const offerId = b64u(random(16))
  return kind === 'qr'
    ? { kind, offerId, secret: random(16) }
    : { kind, offerId, code: generateCode(random) }
}

/** 8 Crockford-base32 characters = 40 bits from 5 random bytes. */
export function generateCode(random: Random = systemRandom): string {
  const bytes = random(5)
  let n = 0n
  for (const b of bytes) n = (n << 8n) | BigInt(b)
  let code = ''
  for (let i = 7; i >= 0; i--) code += CROCKFORD[Number((n >> BigInt(i * 5)) & 31n)]
  return code
}

/** As shown on the computer: ABCD-EFGH. */
export function formatCode(code: string): string {
  return `${code.slice(0, 4)}-${code.slice(4)}`
}

/** What the person typed → canonical code: case-folded, I/L→1, O→0, dashes and spaces dropped. */
export function normalizeCode(input: string): string {
  const code = input.toUpperCase().replace(/[\s-]/g, '').replace(/[IL]/g, '1').replace(/O/g, '0')
  if (code.length !== 8 || [...code].some((c) => !CROCKFORD.includes(c)))
    fail('wrong-code', 'not an 8-character code')
  return code
}

export function pairLink(gateway: string, offerId: string, secret?: Uint8Array): string {
  if (!GATEWAY.test(gateway) || !TOKEN.test(offerId)) fail('bad-message', 'pair link parts')
  return `https://${gateway}/pair/${offerId}${secret ? `#${b64u(secret)}` : ''}`
}

/** A scanned QR or an opened link → gateway, offer and (QR only) the secret. */
export function parsePairLink(link: string): {
  gateway: string
  offerId: string
  secret?: Uint8Array
} {
  const m = /^https:\/\/([^/#?]+)\/pair\/([A-Za-z0-9_-]{22})(?:#([A-Za-z0-9_-]{22}))?$/.exec(
    link.trim(),
  )
  if (!m || !GATEWAY.test(m[1]!)) fail('bad-message', 'not a Buff pairing link')
  return m[3]
    ? { gateway: m[1]!, offerId: m[2]!, secret: fromB64uLength(m[3], 16) }
    : { gateway: m[1]!, offerId: m[2]! }
}

/** The key both sides seal their cards with. Async: Argon2id must not freeze the phone's UI. */
export async function pairingKey(secret: PairingSecret): Promise<Uint8Array> {
  if (secret.kind === 'qr') {
    if (secret.secret.length !== 16) fail('bad-encoding', 'QR secret must be 16 bytes')
    return hkdf(sha256, secret.secret, utf8('buff-pair/v1/qr'), utf8(secret.offerId), 32)
  }
  const salt = sha256(utf8(`buff-pair/v1/code|${secret.offerId}`))
  return argon2idAsync(utf8(normalizeCode(secret.code)), salt, {
    ...CODE_KDF,
    dkLen: 32,
    asyncTick: 10,
  })
}

export function sealOfferBody(
  key: Uint8Array,
  offerId: string,
  body: OfferBody,
  random: Random = systemRandom,
): string {
  return seal(key, 'offer', offerId, body, random)
}

export function openOfferBody(
  key: Uint8Array,
  offerId: string,
  sealed: string,
): OfferBody & { keys: PeerKeys } {
  const b = open(key, 'offer', offerId, sealed)
  if (b.kind !== 'install' && b.kind !== 'machine' && b.kind !== 'saas')
    fail('bad-message', 'offer kind')
  return {
    card: b.card as PeerCard,
    kind: b.kind,
    display: display(b.display),
    keys: verifyPeerCard(b.card),
  }
}

export function sealClaimBody(
  key: Uint8Array,
  offerId: string,
  body: ClaimBody,
  random: Random = systemRandom,
): string {
  return seal(key, 'claim', offerId, body, random)
}

/** `kind` is the offer's: on the code path the commitment is mandatory, so the SAS step cannot be skipped. */
export function openClaimBody(
  key: Uint8Array,
  offerId: string,
  sealed: string,
  kind: OfferKind,
): ClaimBody & { keys: PeerKeys } {
  const b = open(key, 'claim', offerId, sealed)
  const keys = verifyPeerCard(b.card)
  const base = { card: b.card as PeerCard, display: display(b.display), keys }
  if (kind === 'qr') return base
  if (typeof b.commit !== 'string' || b.commit.length !== 43) fail('bad-message', 'commit')
  return { ...base, commit: b.commit }
}

/** Claimer: a fresh nonce and its commitment (goes into the sealed claim body). */
export function createCommitment(random: Random = systemRandom): {
  nonce: Uint8Array
  commit: string
} {
  const nonce = random(16)
  return { nonce, commit: b64u(commitTo(nonce)) }
}

/** Offerer: the revealed nonce must match the commitment received with the claim. */
export function verifyReveal(commit: string, reveal: string): Uint8Array {
  const nonce = fromB64uLength(reveal, 16)
  if (!equalBytes(commitTo(nonce), fromB64uLength(commit, 32)))
    fail('commit-mismatch', 'reveal does not match commitment')
  return nonce
}

export interface SasInput {
  readonly offerId: string
  readonly offerer: PeerCard
  readonly claimer: PeerCard
  readonly claimerNonce: Uint8Array
  readonly offererNonce: Uint8Array
}

/** The 6 digits both screens show on the code path. */
export function sas(input: SasInput): string {
  const digest = sha256(
    encodeJson([
      'buff-sas/v1',
      input.offerId,
      input.offerer.id,
      input.offerer.dh,
      input.claimer.id,
      input.claimer.dh,
      b64u(input.claimerNonce),
      b64u(input.offererNonce),
    ]),
  )
  return String(readU32be(digest) % 1_000_000).padStart(6, '0')
}

export function pairId(offerId: string, offerer: string, claimer: string): string {
  return b64u(sha256(encodeJson(['buff-pair-id/v1', offerId, offerer, claimer])).subarray(0, 16))
}

export function parsePairOffer(value: unknown): PairOfferMessage {
  const m = obj(value)
  if (m.kind !== 'qr' && m.kind !== 'code') fail('bad-message', 'offer kind')
  if (!Number.isSafeInteger(m.expiresAt)) fail('bad-message', 'expiresAt')
  return {
    offerId: token(m.offerId),
    kind: m.kind,
    sealed: sealedText(m.sealed),
    expiresAt: m.expiresAt as number,
  }
}

export function parsePairClaim(value: unknown): PairClaimMessage {
  const m = obj(value)
  return { offerId: token(m.offerId), sealed: sealedText(m.sealed) }
}

export function parsePairClaimReply(value: unknown): PairClaimReply {
  const m = obj(value)
  const sealed = sealedText(m.sealed)
  if (m.nonce === undefined) return { sealed }
  return { sealed, nonce: b64u(fromB64uLength(String(m.nonce), 16)) }
}

export function parsePairReveal(value: unknown): PairRevealMessage {
  const m = obj(value)
  return { offerId: token(m.offerId), reveal: b64u(fromB64uLength(String(m.reveal), 16)) }
}

export function parsePairConfirm(value: unknown): PairConfirmMessage {
  const m = obj(value)
  if (!isPeerId(m.claimer)) fail('bad-peer-id', 'claimer')
  return { offerId: token(m.offerId), claimer: m.claimer }
}

export function parsePairRevoke(value: unknown): PairRevokeMessage {
  return { pairId: token(obj(value).pairId) }
}

function commitTo(nonce: Uint8Array): Uint8Array {
  return sha256(concat(utf8('buff-pair-commit/v1'), nonce))
}

function seal(
  key: Uint8Array,
  role: 'offer' | 'claim',
  offerId: string,
  body: unknown,
  random: Random,
): string {
  const nonce = random(24)
  return b64u(
    concat(nonce, xchacha20poly1305(key, nonce, sealAad(role, offerId)).encrypt(encodeJson(body))),
  )
}

/** Decryption failure here means the code (or QR secret) was wrong — or the box was tampered with. */
function open(
  key: Uint8Array,
  role: 'offer' | 'claim',
  offerId: string,
  sealed: string,
): Record<string, unknown> {
  const bytes = fromB64u(sealed)
  if (bytes.length < 24 + 16) fail('bad-message', 'sealed box too short')
  let plain: Uint8Array
  try {
    plain = xchacha20poly1305(key, bytes.subarray(0, 24), sealAad(role, offerId)).decrypt(
      bytes.subarray(24),
    )
  } catch {
    return fail('wrong-code', 'pairing box did not open')
  }
  return obj(decodeJson(plain))
}

/** Role in the AAD: the gateway cannot reflect a claimer's box back to it as the offer. */
function sealAad(role: 'offer' | 'claim', offerId: string): Uint8Array {
  return encodeJson(['buff-pair-seal/v1', role, offerId])
}

function obj(value: unknown): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value))
    fail('bad-message', 'not an object')
  return value as Record<string, unknown>
}

function token(value: unknown): string {
  return typeof value === 'string' && TOKEN.test(value) ? value : fail('bad-message', 'id')
}

function sealedText(value: unknown): string {
  return typeof value === 'string' && value.length <= 8192
    ? value
    : fail('bad-message', 'sealed box')
}

function display(value: unknown): string {
  return typeof value === 'string' && value.length <= 128
    ? value
    : fail('bad-message', 'display name')
}
