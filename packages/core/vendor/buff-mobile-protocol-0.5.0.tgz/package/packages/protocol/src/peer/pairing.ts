// Pairing a phone, the peer's side (#634, #639). The person starts an offer on the computer; the
// phone claims it through the gateway; this peer opens the sealed claim (only it and the phone hold
// the pairing key), answers with its SAS nonce on the code path, checks the phone's reveal and
// shows the SAS; the person confirms on the computer and only then is the phone recorded — as that
// person, with that person's rights.
//
//   start → offered → claimed → (code) sas | (qr) confirm-ask → paired
//
// Pending offers live in memory: they last minutes, and a restart only means starting over.

import { b64u } from '../encoding.ts'
import { peerCard, type PeerCard } from '../identity.ts'
import {
  createOffer,
  formatCode,
  openClaimBody,
  pairingKey,
  pairLink,
  sas,
  sealOfferBody,
  verifyReveal,
  type PairingSecret,
} from '../pairing.ts'
import { systemRandom, type Random } from '../random.ts'
import { RefusalError, silentLog, type PeerLog, type Reply } from './common.ts'
import type { DeviceRecord, LocalPeer } from './host.ts'

const TTL_SEC = { qr: 5 * 60, code: 15 * 60 } as const

export type PairingState = 'offered' | 'claimed' | 'sas' | 'confirm' | 'paired' | 'failed'

interface Pending {
  local: LocalPeer
  secret: PairingSecret
  key: Uint8Array
  login: string
  org: string | null
  expiresAt: number
  state: PairingState
  claim?: { claimId: string; card: PeerCard; display: string; commit?: string }
  nonce?: Uint8Array
  sas?: string
  error?: string
  /** A demo install's offer (#657): confirmed on claim, the phone recorded as a demo one. */
  demo?: boolean
}

export interface PairingPorts {
  /** A command to the gateway in the local peer's name (relay.cmd.<op>.<peer>). */
  gateway(local: LocalPeer, command: 'offer' | 'answer' | 'confirm', body: object): Promise<Reply>
  saveDevice(record: DeviceRecord): Promise<void>
  /** The gateway's host for links (buff.systems). */
  gatewayHost: string
  now(): number
  /** The error a refusal travels as (the caller's own kind, so its dispatcher says it as it is). */
  refuse?: (message: string) => Error
  random?: Random
  log?: PeerLog
}

export interface PairingView {
  offerId: string
  state: PairingState
  kind: 'qr' | 'code'
  link: string
  code?: string
  expiresAt: number
  phone?: string
  sas?: string
  error?: string
}

export class PairingEngine {
  private readonly pending = new Map<string, Pending>()
  readonly ports: PairingPorts
  private readonly refuse: (message: string) => Error
  private readonly random: Random
  private readonly log: PeerLog

  constructor(ports: PairingPorts) {
    this.ports = ports
    this.refuse = ports.refuse ?? ((m) => new RefusalError(m))
    this.random = ports.random ?? systemRandom
    this.log = ports.log ?? silentLog
  }

  async start(
    local: LocalPeer,
    kind: 'qr' | 'code',
    login: string,
    org: string | null,
    display: string,
    /** A demo install's offer (#657): a QR claim is confirmed with no one at a computer. */
    opts: { demo?: boolean } = {},
  ): Promise<PairingView> {
    this.sweep()
    const secret = createOffer(kind, this.random)
    const key = await pairingKey(secret)
    const expiresAt = this.ports.now() + TTL_SEC[kind]
    const sealed = sealOfferBody(key, secret.offerId, {
      card: peerCard(local.identity),
      kind: local.kind,
      display,
    })
    const got = await this.ports.gateway(local, 'offer', {
      offerId: secret.offerId,
      kind,
      sealed,
      expiresAt: expiresAt * 1000,
    })
    if (!got.ok) throw this.refuse(String(got.error ?? 'the gateway refused the offer'))
    this.pending.set(secret.offerId, {
      local,
      secret,
      key,
      login,
      org,
      expiresAt,
      state: 'offered',
      ...(opts.demo ? { demo: true } : {}),
    })
    return this.view(secret.offerId, login)
  }

  /** What the person who started the offer sees — and only them. */
  view(offerId: string, login: string): PairingView {
    const p = this.pending.get(offerId)
    if (!p || p.login !== login) throw this.refuse('Сопряжение не найдено или истекло.')
    const qr = p.secret.kind === 'qr' ? p.secret.secret : undefined
    return {
      offerId,
      state: p.state,
      kind: p.secret.kind,
      link: pairLink(this.ports.gatewayHost, offerId, qr),
      ...(p.secret.kind === 'code' ? { code: formatCode(p.secret.code) } : {}),
      expiresAt: p.expiresAt,
      ...(p.claim ? { phone: p.claim.display } : {}),
      ...(p.sas ? { sas: p.sas } : {}),
      ...(p.error ? { error: p.error } : {}),
    }
  }

  /** The offers waiting or going on — what a computer shows when it opens its phone screen again. */
  offers(login: string): PairingView[] {
    this.sweep()
    return [...this.pending.entries()]
      .filter(([, p]) => p.login === login && p.state !== 'paired')
      .map(([id]) => this.view(id, login))
  }

  /** The gateway forwarded a phone's sealed claim. A box that does not open is a wrong code. */
  async onClaim(offerId: string, claimId: string, sealedClaim: string): Promise<void> {
    const p = this.live(offerId)
    if (!p || p.state === 'paired') return
    let body
    try {
      body = openClaimBody(p.key, offerId, sealedClaim, p.secret.kind)
    } catch {
      // A wrong code: say so at once, the phone would otherwise wait out its timeout. The offer
      // stays open for the right code (the gateway counts the attempts).
      this.log.warn('relay: a claim did not open (wrong code?)', { offerId })
      await this.ports.gateway(p.local, 'answer', { offerId, claimId, refused: 'wrong-code' })
      return
    }
    const nonce = p.secret.kind === 'code' ? this.random(16) : undefined
    Object.assign(p, {
      claim: { claimId, card: body.card, display: body.display, commit: body.commit },
      nonce,
      state: p.secret.kind === 'code' ? 'claimed' : 'confirm',
    })
    await this.ports.gateway(p.local, 'answer', {
      offerId,
      claimId,
      ...(nonce ? { nonce: b64u(nonce) } : {}),
    })
    // A demo offer is a QR one (the claim opened with its secret): no one confirms at a computer.
    if (p.demo && p.secret.kind === 'qr') await this.confirm(offerId, p.login)
  }

  /** The phone revealed its nonce: the SAS can be shown on both screens. */
  onReveal(offerId: string, claimId: string, reveal: string): void {
    const p = this.live(offerId)
    if (!p?.claim || p.claim.claimId !== claimId || !p.nonce || !p.claim.commit) return
    try {
      const phoneNonce = verifyReveal(p.claim.commit, reveal)
      p.sas = sas({
        offerId,
        offerer: peerCard(p.local.identity),
        claimer: p.claim.card,
        claimerNonce: phoneNonce,
        offererNonce: p.nonce,
      })
      p.state = 'sas'
    } catch {
      Object.assign(p, { state: 'failed', error: 'Код сверки не сошёлся — начните заново.' })
    }
  }

  /** The person confirmed on the computer (the SAS matched / the phone is theirs). */
  async confirm(offerId: string, login: string): Promise<PairingView> {
    const p = this.live(offerId)
    if (!p || p.login !== login) throw this.refuse('Сопряжение не найдено или истекло.')
    if (!p.claim || (p.state !== 'sas' && p.state !== 'confirm'))
      throw this.refuse('Телефон ещё не подключился.')
    const got = await this.ports.gateway(p.local, 'confirm', {
      offerId,
      claimId: p.claim.claimId,
      claimer: p.claim.card.id,
      display: p.claim.display,
      user: p.login,
    })
    if (!got.ok) throw this.refuse(String(got.error ?? 'the gateway refused the pairing'))
    await this.ports.saveDevice({
      peer: p.local.identity.id,
      device: p.claim.card.id,
      dh: p.claim.card.dh,
      display: p.claim.display,
      pairId: String(got.pairId),
      created: this.ports.now(),
      login: p.login,
      org: p.org,
      ...(p.demo ? { demo: true } : {}),
    })
    p.state = 'paired'
    return this.view(offerId, login)
  }

  cancel(offerId: string, login: string): void {
    if (this.pending.get(offerId)?.login === login) this.pending.delete(offerId)
  }

  private live(offerId: string): Pending | null {
    const p = this.pending.get(offerId)
    if (!p) return null
    if (p.expiresAt <= this.ports.now() && p.state !== 'paired') {
      this.pending.delete(offerId)
      return null
    }
    return p
  }

  private sweep(): void {
    for (const id of [...this.pending.keys()]) this.live(id)
  }
}
