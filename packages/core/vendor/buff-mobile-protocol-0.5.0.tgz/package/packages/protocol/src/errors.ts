// One error type for the whole protocol. The `code` is what callers branch on: the phone maps it
// to a screen («код истёк», «несовместимая версия», …), the gateway to a refusal reply.

export type ProtocolErrorCode =
  | 'bad-encoding'
  | 'bad-message'
  | 'bad-peer-id'
  | 'bad-signature'
  | 'too-large'
  | 'decrypt-failed'
  | 'replay'
  | 'incompatible-version'
  | 'wrong-code'
  | 'commit-mismatch'

export class ProtocolError extends Error {
  readonly code: ProtocolErrorCode

  constructor(code: ProtocolErrorCode, message: string) {
    super(message)
    this.name = 'ProtocolError'
    this.code = code
  }
}

export function fail(code: ProtocolErrorCode, message: string): never {
  throw new ProtocolError(code, message)
}
