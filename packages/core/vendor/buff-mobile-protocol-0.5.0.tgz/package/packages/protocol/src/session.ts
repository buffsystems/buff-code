// Connection setup and the E2E envelope. On every (re)connect the initiator runs Noise KK with the
// paired peer; the two handshake payloads carry the version range and the largest payload each
// side accepts. Split() yields one key per direction; each message is then XChaCha20-Poly1305 under
// that key with the nonce sid‖seq (16 + 8 bytes) and the frame header as AAD. A receiver accepts
// only a strictly growing seq per session, so a replayed or reordered frame is refused.
//
// A payload bigger than one frame goes as parts (#739): seal() returns one frame per part, open()
// returns the whole payload with the last part and null before it. Parts ride the session's own
// order (consecutive seq), so they need no id, key or checksum of their own; a part lost on the way
// leaves the assembly unfinished, and the next payload simply starts over.

import { xchacha20poly1305 } from '@noble/ciphers/chacha.js'
import { hkdf } from '@noble/hashes/hkdf.js'
import { sha256 } from '@noble/hashes/sha2.js'
import { b64u, concat, decodeJson, encodeJson, fromB64u, u64be, utf8 } from './encoding.ts'
import { fail } from './errors.ts'
import { encodeFrame, type HandshakeFrame, type MessageFrame } from './frames.ts'
import type { Identity, PeerKeys } from './identity.ts'
import {
  type KkInitiatorState,
  type KkParams,
  kkReadMessage2,
  kkRespond,
  kkWriteMessage1,
  type SplitKeys,
} from './noise.ts'
import { decodePayload, encodePayload, type Payload } from './payload.ts'
import { type Random, systemRandom } from './random.ts'
import { negotiateVersion, SUPPORTED_VERSIONS, type VersionRange } from './version.ts'

export const PROLOGUE = utf8('buff-relay/v1')
/** Payload bytes one frame carries; beyond it, a payload goes as parts of this size. */
export const PART_BYTES = 128 * 1024
/** The largest payload a peer takes assembled from parts, unless it announces another (16 MiB). */
export const DEFAULT_MAX_BYTES = 16 * 1024 * 1024

export interface HandshakeOptions {
  readonly local: Identity
  /** The paired peer, from the local pair store — never from the frame. */
  readonly remote: PeerKeys
  readonly versions?: VersionRange
  /** The largest payload this side assembles from parts. */
  readonly maxBytes?: number
  readonly random?: Random
}

export interface Session {
  readonly sid: string
  readonly version: number
  readonly local: string
  readonly remote: string
  /** The largest payload the remote assembles from parts. */
  readonly remoteMaxBytes: number
  readonly handshakeHash: Uint8Array
  /** Encrypt one payload into wire frames — one, or one per part (throws too-large before
   *  consuming a counter when it is over what the remote takes). */
  seal(payload: Payload): Uint8Array[]
  /** Decrypt and validate one inbound frame; null while a payload's parts are still arriving. */
  open(frame: MessageFrame): Payload | null
}

export interface PendingHandshake {
  readonly frame: HandshakeFrame
  readonly state: KkInitiatorState
  readonly options: HandshakeOptions
}

interface Hello {
  readonly v: VersionRange
  readonly maxBytes: number
}

type HelloReply =
  | { readonly v: number; readonly maxBytes: number }
  | { readonly error: 'incompatible-version'; readonly v: VersionRange }

export function startHandshake(options: HandshakeOptions): PendingHandshake {
  const random = options.random ?? systemRandom
  const hello: Hello = { v: options.versions ?? SUPPORTED_VERSIONS, maxBytes: maxBytes(options) }
  const { message, state } = kkWriteMessage1(kkParams(options, random), encodeJson(hello))
  const frame: HandshakeFrame = {
    t: 'hs1',
    from: options.local.id,
    to: options.remote.id,
    hid: b64u(random(16)),
    m: b64u(message),
  }
  return { frame, state, options }
}

/**
 * Responder side. Always returns a reply frame; `session` is null when the versions do not overlap
 * (the reply then tells the initiator so, and its finishHandshake throws incompatible-version).
 */
export function acceptHandshake(
  options: HandshakeOptions,
  frame: HandshakeFrame,
): { frame: HandshakeFrame; session: Session | null } {
  checkAddressing(frame, 'hs1', options)
  const random = options.random ?? systemRandom
  const local = options.versions ?? SUPPORTED_VERSIONS
  const outcome: { reply: HelloReply } = { reply: { error: 'incompatible-version', v: local } }
  const { payload, message, keys } = kkRespond(
    kkParams(options, random),
    fromB64u(frame.m),
    (bytes) => {
      const version = negotiateVersion(local, parseHello(decodeJson(bytes)).v)
      if (version !== null) outcome.reply = { v: version, maxBytes: maxBytes(options) }
      return encodeJson(outcome.reply)
    },
  )
  const hello = parseHello(decodeJson(payload))
  const reply = outcome.reply
  const out: HandshakeFrame = {
    t: 'hs2',
    from: options.local.id,
    to: options.remote.id,
    hid: frame.hid,
    m: b64u(message),
  }
  if ('error' in reply) return { frame: out, session: null }
  return { frame: out, session: createSession(options, keys, reply.v, hello.maxBytes, false) }
}

export function finishHandshake(pending: PendingHandshake, frame: HandshakeFrame): Session {
  checkAddressing(frame, 'hs2', pending.options)
  if (frame.hid !== pending.frame.hid) fail('bad-message', 'handshake id mismatch')
  const { payload, keys } = kkReadMessage2(pending.state, fromB64u(frame.m))
  const reply = decodeJson(payload) as Record<string, unknown> | null
  if (typeof reply !== 'object' || reply === null || Array.isArray(reply))
    fail('bad-message', 'handshake reply')
  if (reply.error === 'incompatible-version') {
    const v = reply.v as VersionRange
    fail('incompatible-version', `peer speaks protocol ${v?.min}..${v?.max}`)
  }
  const local = pending.options.versions ?? SUPPORTED_VERSIONS
  const version = reply.v
  if (
    !Number.isSafeInteger(version) ||
    (version as number) < local.min ||
    (version as number) > local.max
  ) {
    fail('incompatible-version', 'peer chose a version outside our range')
  }
  if (!Number.isSafeInteger(reply.maxBytes) || (reply.maxBytes as number) < 0)
    fail('bad-message', 'maxBytes')
  return createSession(pending.options, keys, version as number, reply.maxBytes as number, true)
}

function createSession(
  options: HandshakeOptions,
  keys: SplitKeys,
  version: number,
  remoteMaxBytes: number,
  initiator: boolean,
): Session {
  const sidBytes = hkdf(sha256, keys.handshakeHash, undefined, utf8('buff-relay/v1/sid'), 16)
  const sid = b64u(sidBytes)
  const sendKey = initiator ? keys.k1 : keys.k2
  const recvKey = initiator ? keys.k2 : keys.k1
  const local = options.local.id
  const remote = options.remote.id
  let sendSeq = 0
  let lastRecv = -1
  const localMaxBytes = maxBytes(options)
  const maxParts = Math.ceil(localMaxBytes / PART_BYTES)
  /** The parts of the payload arriving now, in order. */
  let parts: { n: number; chunks: Uint8Array[] } | null = null

  const frame = (plain: Uint8Array): Uint8Array => {
    const seq = sendSeq
    const header = { v: version, from: local, to: remote, sid, seq }
    const ct = xchacha20poly1305(sendKey, concat(sidBytes, u64be(seq)), aad(header)).encrypt(plain)
    const bytes = encodeFrame({ t: 'msg', ...header, ct: b64u(ct) })
    sendSeq = seq + 1
    return bytes
  }

  return {
    sid,
    version,
    local,
    remote,
    remoteMaxBytes,
    handshakeHash: keys.handshakeHash,
    seal(payload) {
      const plain = encodePayload(payload)
      if (plain.length <= PART_BYTES) return [frame(plain)]
      if (plain.length > remoteMaxBytes)
        fail('too-large', `payload of ${plain.length} bytes over the peer's ${remoteMaxBytes}`)
      const n = Math.ceil(plain.length / PART_BYTES)
      return Array.from({ length: n }, (_, idx) => {
        const data = b64u(plain.subarray(idx * PART_BYTES, (idx + 1) * PART_BYTES))
        return frame(encodePayload({ kind: 'part', idx, n, data }))
      })
    },
    open(frame) {
      if (frame.from !== remote || frame.to !== local || frame.sid !== sid || frame.v !== version) {
        fail('bad-message', 'frame does not belong to this session')
      }
      if (frame.seq <= lastRecv) fail('replay', `seq ${frame.seq} after ${lastRecv}`)
      let plaintext: Uint8Array
      try {
        plaintext = xchacha20poly1305(
          recvKey,
          concat(sidBytes, u64be(frame.seq)),
          aad(frame),
        ).decrypt(fromB64u(frame.ct))
      } catch {
        return fail('decrypt-failed', 'envelope did not authenticate')
      }
      lastRecv = frame.seq
      const payload = decodePayload(plaintext)
      if (payload.kind !== 'part') {
        parts = null // an assembly left unfinished by a lost part
        return payload
      }
      if (payload.idx === 0) {
        if (payload.n > maxParts)
          fail('too-large', `${payload.n} parts over the ${maxParts} announced`)
        parts = { n: payload.n, chunks: [] }
      } else if (!parts || payload.idx !== parts.chunks.length || payload.n !== parts.n) {
        parts = null
        fail('bad-message', `part ${payload.idx} of ${payload.n} out of order`)
      }
      parts.chunks.push(fromB64u(payload.data))
      if (parts.chunks.length < parts.n) return null
      const whole = decodePayload(concat(...parts.chunks))
      parts = null
      if (whole.kind === 'part') fail('bad-message', 'a part inside parts')
      return whole
    },
  }
}

/** The authenticated header: everything the relay sees except the ciphertext itself. */
function aad(h: { v: number; from: string; to: string; sid: string; seq: number }): Uint8Array {
  return encodeJson(['buff-env', h.v, h.from, h.to, h.sid, h.seq])
}

function kkParams(options: HandshakeOptions, random: Random): KkParams {
  return {
    prologue: PROLOGUE,
    local: { secret: options.local.dhSecret, public: options.local.dhPublic },
    remotePublic: options.remote.dhPublic,
    ephemeralSecret: random(32),
  }
}

function checkAddressing(frame: HandshakeFrame, t: 'hs1' | 'hs2', options: HandshakeOptions): void {
  if (frame.t !== t || frame.from !== options.remote.id || frame.to !== options.local.id) {
    fail('bad-message', `unexpected ${frame.t} from ${frame.from}`)
  }
}

function maxBytes(options: HandshakeOptions): number {
  return options.maxBytes ?? DEFAULT_MAX_BYTES
}

function parseHello(value: unknown): Hello {
  const h = value as { v?: { min?: unknown; max?: unknown }; maxBytes?: unknown } | null
  const min = h?.v?.min
  const max = h?.v?.max
  if (
    !Number.isSafeInteger(min) ||
    !Number.isSafeInteger(max) ||
    !Number.isSafeInteger(h?.maxBytes)
  )
    fail('bad-message', 'hello')
  return { v: { min: min as number, max: max as number }, maxBytes: h!.maxBytes as number }
}
