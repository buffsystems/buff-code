// Push notifications (#635, #636): an install or a Buff Code machine tells a paired phone something
// happened while the app is closed. The gateway hands the message to APNs/FCM, so it must not be
// able to read it — nor Apple or Google: the message is sealed for the device with a key both
// sides derive from their static keys (X25519 of the pair, HKDF with both ids), never the session.
// A fresh random nonce per message; the ids are authenticated, so a message cannot be re-addressed.

import { xchacha20poly1305 } from '@noble/ciphers/chacha.js'
import { x25519 } from '@noble/curves/ed25519.js'
import { hkdf } from '@noble/hashes/hkdf.js'
import { sha256 } from '@noble/hashes/sha2.js'
import { b64u, decodeJson, encodeJson, fromB64u, fromB64uLength, utf8 } from './encoding.ts'
import { fail } from './errors.ts'
import type { Identity } from './identity.ts'
import { type Random, systemRandom } from './random.ts'

/** What the phone shows: a line, a sentence and the screen it opens (`buff://<install>/<section>/<id>`). */
export interface PushMessage {
  readonly title: string
  readonly body: string
  readonly link: string
  /** When it happened (epoch seconds). */
  readonly at: number
  /** The notice type (`gate_ready`, `bc_permission`, …): the phone's icon and filter. */
  readonly type?: string
}

/** The sealed message as it travels: who sent it and the ciphertext; the gateway sees nothing else. */
export interface SealedPush {
  readonly v: 1
  readonly from: string
  readonly n: string
  readonly ct: string
}

/** The other side of the pair: its id and static DH key. */
export interface PushPeer {
  readonly id: string
  readonly dhPublic: Uint8Array
}

const LIMITS = { title: 120, body: 600, link: 300, type: 40 } as const
/** APNs and FCM carry 4 KB; the sealed message stays well under it. */
export const PUSH_MAX_CT_BYTES = 3 * 1024

function pushKey(own: Identity, other: PushPeer, from: string, to: string): Uint8Array {
  const shared = x25519.getSharedSecret(own.dhSecret, other.dhPublic)
  return hkdf(sha256, shared, utf8('buff-push/v1'), utf8(`${from}|${to}`), 32)
}

const aad = (from: string, to: string) => encodeJson(['buff-push', 1, from, to])

function checked(message: PushMessage): PushMessage {
  for (const field of ['title', 'body', 'link'] as const) {
    const value = message[field]
    if (typeof value !== 'string' || value.length > LIMITS[field])
      fail('too-large', `push ${field}`)
  }
  if (!Number.isInteger(message.at)) fail('bad-message', 'push at')
  const type = message.type
  if (type !== undefined && (typeof type !== 'string' || type.length > LIMITS.type))
    fail('too-large', 'push type')
  const { title, body, link, at } = message
  return type === undefined ? { title, body, link, at } : { title, body, link, at, type }
}

/** The sender seals a message for a paired device. */
export function sealPush(
  from: Identity,
  to: PushPeer,
  message: PushMessage,
  random: Random = systemRandom,
): SealedPush {
  const nonce = random(24)
  const ct = xchacha20poly1305(
    pushKey(from, to, from.id, to.id),
    nonce,
    aad(from.id, to.id),
  ).encrypt(encodeJson(checked(message)))
  if (ct.length > PUSH_MAX_CT_BYTES) fail('too-large', 'push message')
  return { v: 1, from: from.id, n: b64u(nonce), ct: b64u(ct) }
}

/** The device opens a message from a peer it is paired with. */
export function openPush(me: Identity, from: PushPeer, sealed: SealedPush): PushMessage {
  if (sealed.v !== 1 || sealed.from !== from.id) fail('bad-message', 'push from another peer')
  let plain: Uint8Array
  try {
    plain = xchacha20poly1305(
      pushKey(me, from, from.id, me.id),
      fromB64uLength(sealed.n, 24),
      aad(from.id, me.id),
    ).decrypt(fromB64u(sealed.ct))
  } catch {
    return fail('decrypt-failed', 'push did not authenticate')
  }
  return checked(decodeJson(plain) as PushMessage)
}
