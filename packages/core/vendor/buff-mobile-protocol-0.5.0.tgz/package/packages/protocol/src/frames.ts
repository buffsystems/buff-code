// Wire frames on `relay.<to>.in.<from>`. The relay sees exactly this: who to whom, a handshake id or a
// session id with a counter, and opaque bytes. JSON keeps the frames readable in middleware logs
// and identical across runtimes.

import { decodeJson, encodeJson } from './encoding.ts'
import { fail } from './errors.ts'
import { isPeerId } from './identity.ts'

/** The relay's message ceiling; a bigger payload goes as parts (session.ts). */
export const MAX_FRAME_BYTES = 256 * 1024

export interface HandshakeFrame {
  readonly t: 'hs1' | 'hs2'
  readonly from: string
  readonly to: string
  /** Handshake id chosen by the initiator, echoed in hs2. */
  readonly hid: string
  /** Noise message, base64url. */
  readonly m: string
}

export interface MessageFrame {
  readonly t: 'msg'
  readonly v: number
  readonly from: string
  readonly to: string
  readonly sid: string
  readonly seq: number
  /** XChaCha20-Poly1305 ciphertext of the payload, base64url. */
  readonly ct: string
}

/** «I hold no session with you — say hello again» (the install restarted). Not sealed: only the
 *  paired peer may publish on this subject, and the worst it can do is cost one handshake. */
export interface ResetFrame {
  readonly t: 'rst'
  readonly from: string
  readonly to: string
}

export type Frame = HandshakeFrame | MessageFrame | ResetFrame

const TOKEN = /^[A-Za-z0-9_-]{22}$/
const B64U = /^[A-Za-z0-9_-]*$/

export function encodeFrame(frame: Frame): Uint8Array {
  const bytes = encodeJson(frame)
  if (bytes.length > MAX_FRAME_BYTES) fail('too-large', `frame of ${bytes.length} bytes`)
  return bytes
}

export function decodeFrame(bytes: Uint8Array): Frame {
  if (bytes.length > MAX_FRAME_BYTES) fail('too-large', `frame of ${bytes.length} bytes`)
  const value = decodeJson(bytes)
  if (typeof value !== 'object' || value === null) fail('bad-message', 'frame')
  const f = value as Record<string, unknown>
  if (!isPeerId(f.from) || !isPeerId(f.to)) fail('bad-peer-id', 'frame from/to')
  if ((f.t === 'hs1' || f.t === 'hs2') && token(f.hid) && b64(f.m)) {
    return { t: f.t, from: f.from, to: f.to, hid: f.hid as string, m: f.m as string }
  }
  if (f.t === 'rst') return { t: 'rst', from: f.from, to: f.to }
  if (
    f.t === 'msg' &&
    Number.isSafeInteger(f.v) &&
    token(f.sid) &&
    Number.isSafeInteger(f.seq) &&
    b64(f.ct)
  ) {
    if ((f.seq as number) < 0) fail('bad-message', 'seq')
    return {
      t: 'msg',
      v: f.v as number,
      from: f.from,
      to: f.to,
      sid: f.sid as string,
      seq: f.seq as number,
      ct: f.ct as string,
    }
  }
  return fail('bad-message', 'frame shape')
}

function token(value: unknown): boolean {
  return typeof value === 'string' && TOKEN.test(value)
}

function b64(value: unknown): boolean {
  return typeof value === 'string' && B64U.test(value)
}
