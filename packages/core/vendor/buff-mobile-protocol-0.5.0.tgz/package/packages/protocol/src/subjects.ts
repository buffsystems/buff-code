// Subject naming on the middleware's `relay` plane and who may use which subject — kept as data so
// the middleware callout (#632), the gateway (#633) and the tests read one definition. Every id
// placed in a subject is validated first: a peer id is 43 base64url characters and a guest id 22,
// neither can contain the NATS separators or wildcards (. * >).
//
// The SENDER is always the last token of the subject a client may publish to, and NATS permissions
// pin it to the client's own id. So a receiver and the gateway learn who sent a message from the
// subject — not from the body — and the middleware can count traffic per sender without reading it.
//
//   relay.<to>.in.<from>        frames between paired peers
//   relay.cmd.<op>.<sender>     commands to the gateway (sender = peer id, or guest id)
//   relay.reply.<client>.<…>    the gateway's replies (the client's inbox prefix)
//   relay.ctrl.<peer>           service messages from the gateway: pairs-changed, policy, limits

import { fail } from './errors.ts'
import { isPeerId } from './identity.ts'

/** Commands a peer holding a token may send. */
export const PEER_COMMANDS = [
  'register',
  'offer',
  'answer',
  'confirm',
  'revoke',
  'token',
  // Push (#635): a device names its APNs/FCM handle, a peer sends a sealed message to its pair.
  'push_handle',
  'push_send',
  // A demo install answers a phone's demo request with a fresh pairing link (#657).
  'demo_link',
] as const
/** Commands a guest may send: a phone before pairing, a new machine, a kicked peer renewing its token,
 *  a phone asking a demo install for a pairing link (#657). */
export const GUEST_COMMANDS = ['register', 'claim', 'reveal', 'token', 'demo'] as const

export type RelayCommand = (typeof PEER_COMMANDS)[number] | (typeof GUEST_COMMANDS)[number]

export interface Permissions {
  readonly publish: readonly string[]
  readonly subscribe: readonly string[]
}

const GUEST_ID = /^[A-Za-z0-9_-]{22}$/
const COMMANDS = new Set<string>([...PEER_COMMANDS, ...GUEST_COMMANDS])

export function isGuestId(value: unknown): value is string {
  return typeof value === 'string' && GUEST_ID.test(value)
}

/** Frames from `from` to `to`. */
export function inboxSubject(to: string, from: string): string {
  return `relay.${peer(to)}.in.${peer(from)}`
}

/** Who sent a frame, from the subject it arrived on (null when it is not an inbox subject). */
export function parseInboxSubject(subject: string): { to: string; from: string } | null {
  const t = subject.split('.')
  if (t.length !== 4 || t[0] !== 'relay' || t[2] !== 'in' || !isPeerId(t[1]) || !isPeerId(t[3])) {
    return null
  }
  return { to: t[1], from: t[3] }
}

export function commandSubject(command: RelayCommand, sender: string): string {
  if (!isPeerId(sender) && !isGuestId(sender)) fail('bad-peer-id', 'command sender')
  return `relay.cmd.${command}.${sender}`
}

/** Command and sender of a gateway command (null when it is not one). */
export function parseCommandSubject(
  subject: string,
): { command: RelayCommand; sender: string } | null {
  const t = subject.split('.')
  if (t.length !== 4 || t[0] !== 'relay' || t[1] !== 'cmd' || !COMMANDS.has(t[2]!)) return null
  if (!isPeerId(t[3]) && !isGuestId(t[3])) return null
  return { command: t[2] as RelayCommand, sender: t[3]! }
}

/** The client's reply-inbox prefix (nats.js `inboxPrefix`); replies to it travel from the gateway. */
export function replyPrefix(clientId: string): string {
  if (!isPeerId(clientId) && !isGuestId(clientId)) fail('bad-peer-id', 'client id')
  return `relay.reply.${clientId}`
}

/** Service messages for this peer from the gateway: pairs-changed, policy, teardown, limits. */
export function ctrlSubject(peerId: string): string {
  return `relay.ctrl.${peer(peerId)}`
}

/**
 * A peer holding a valid token: frames only to and from its pairs, its own commands, its own
 * control and reply subjects. A pair missing from the token cuts both directions.
 */
export function peerPermissions(self: string, pairs: readonly string[]): Permissions {
  const unique = [...new Set(pairs)].filter((p) => p !== self)
  return {
    publish: [
      ...unique.map((p) => inboxSubject(p, self)),
      ...PEER_COMMANDS.map((c) => commandSubject(c, self)),
    ],
    subscribe: [
      ...unique.map((p) => inboxSubject(self, p)),
      ctrlSubject(self),
      `${replyPrefix(self)}.>`,
    ],
  }
}

/** A guest (no token). `guestId` is the client's random id, carried in its connect token. */
export function guestPermissions(guestId: string): Permissions {
  return {
    publish: GUEST_COMMANDS.map((c) => commandSubject(c, guestId)),
    subscribe: [`${replyPrefix(guestId)}.>`],
  }
}

/** NATS subject matching (`*` one token, `>` the rest) — lets tests check a subject against Permissions. */
export function subjectMatches(pattern: string, subject: string): boolean {
  const p = pattern.split('.')
  const s = subject.split('.')
  for (let i = 0; i < p.length; i++) {
    if (p[i] === '>') return s.length > i
    if (i >= s.length || (p[i] !== '*' && p[i] !== s[i])) return false
  }
  return p.length === s.length
}

export function mayUse(allowed: readonly string[], subject: string): boolean {
  return allowed.some((pattern) => subjectMatches(pattern, subject))
}

function peer(peerId: string): string {
  return isPeerId(peerId) ? peerId : fail('bad-peer-id', 'peer id')
}
