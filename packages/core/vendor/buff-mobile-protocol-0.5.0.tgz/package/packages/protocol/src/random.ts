// Randomness is injected everywhere it is consumed so test vectors are reproducible. Production uses
// the platform CSPRNG (crypto.getRandomValues; on React Native it comes from
// react-native-get-random-values, imported once by the app).

import { randomBytes } from '@noble/hashes/utils.js'

export type Random = (length: number) => Uint8Array

export const systemRandom: Random = (length) => randomBytes(length)
