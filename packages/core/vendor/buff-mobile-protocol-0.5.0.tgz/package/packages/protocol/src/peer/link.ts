// One local peer on the relay (#634, #639): an outbound connection to the middleware's relay plane
// with the peer's token, subscribed to exactly its pairs' frames, its control subject and its
// replies. Frames go to the RelayHost, the gateway's control messages to the PairingEngine and to
// the host (a revoked phone loses its session at once). The token is renewed before it expires
// and on every pairs-changed: a new connection with the new token comes up, then the old closes.

import { b64u, fromUtf8, utf8 } from '../encoding.ts'
import { peerCard, type Identity } from '../identity.ts'
import { signProof } from '../gateway.ts'
import { systemRandom, type Random } from '../random.ts'
import { commandSubject, ctrlSubject, inboxSubject, replyPrefix } from '../subjects.ts'
import { silentLog, type PeerLog, type Reply } from './common.ts'
import type { LocalPeer, RelayHost } from './host.ts'
import type { PairingEngine } from './pairing.ts'

/** The slice of a NATS connection (nats, nats.ws) the link uses. */
export interface RelayConn {
  subscribe(
    subject: string,
    opts: { callback: (err: unknown, msg: { subject: string; data: Uint8Array }) => void },
  ): { unsubscribe(): void }
  publish(subject: string, data: Uint8Array): void
  close(): Promise<void>
  closed(): Promise<void | Error>
}

export interface RelayToken {
  token: string
  exp: number
  pairs: string[]
}

export interface LinkDeps {
  local: LocalPeer
  /** A fresh token for this peer (a SaaS org: signed locally; an install or a machine: from the gateway). */
  token(): Promise<RelayToken>
  connect(token: string): Promise<RelayConn>
  host: RelayHost
  engine: PairingEngine
  now(): number
  random?: Random
  log?: PeerLog
  /** A demo install (#657): a fresh pairing link for a phone that asked; null — not a demo now. */
  demo?: () => Promise<string | null>
}

const RENEW_BEFORE_SEC = 120
const RETRY_SEC = [2, 5, 15, 30, 60]
const json = (v: unknown): Uint8Array => utf8(JSON.stringify(v))

export class RelayLink {
  private conn: RelayConn | null = null
  private current: RelayToken | null = null
  private timer: ReturnType<typeof setTimeout> | null = null
  private stopped = false
  private failures = 0
  readonly d: LinkDeps
  private readonly log: PeerLog
  private readonly random: Random

  constructor(deps: LinkDeps) {
    this.d = deps
    this.log = deps.log ?? silentLog
    this.random = deps.random ?? systemRandom
  }

  get id(): string {
    return this.d.local.identity.id
  }

  /** The pairs the current token grants — what the host checks every frame against. */
  pairs(): readonly string[] {
    return this.current?.pairs ?? []
  }

  async start(): Promise<void> {
    this.stopped = false
    await this.reconnect('start')
  }

  async stop(): Promise<void> {
    this.stopped = true
    if (this.timer) clearTimeout(this.timer)
    await this.conn?.close().catch(() => undefined)
    this.conn = null
  }

  get connected(): boolean {
    return this.conn !== null
  }

  /** A fresh token and connection now — after a pairing or a revocation made here. */
  refresh(why: string): Promise<void> {
    return this.reconnect(why)
  }

  publish(subject: string, bytes: Uint8Array): void {
    this.conn?.publish(subject, bytes)
  }

  /** A command to the gateway in this peer's name; the answer comes on its reply prefix. */
  request(command: string, body: object, timeoutMs = 10_000): Promise<Reply> {
    const conn = this.conn
    if (!conn) return Promise.resolve({ ok: false, error: 'relay: not connected' })
    const reply = `${replyPrefix(this.id)}.${b64u(this.random(8))}`
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        sub.unsubscribe()
        resolve({ ok: false, error: 'relay: the gateway did not answer' })
      }, timeoutMs)
      const sub = conn.subscribe(reply, {
        callback: (_e, m) => {
          clearTimeout(timer)
          sub.unsubscribe()
          try {
            resolve(JSON.parse(fromUtf8(m.data)) as Reply)
          } catch {
            resolve({ ok: false, error: 'relay: unreadable answer' })
          }
        },
      })
      conn.publish(
        commandSubject(command as Parameters<typeof commandSubject>[0], this.id),
        json({ ...body, reply }),
      )
    })
  }

  /** Why the last connection attempt failed; null while connected. */
  problem: string | null = null

  private async reconnect(why: string): Promise<void> {
    if (this.stopped) return
    if (this.timer) clearTimeout(this.timer)
    try {
      const token = await this.d.token()
      const conn = await this.d.connect(token.token)
      this.subscribe(conn, token)
      const old = this.conn
      const dropped = (this.current?.pairs ?? []).filter((p) => !token.pairs.includes(p))
      ;[this.conn, this.current, this.failures, this.problem] = [conn, token, 0, null]
      dropped.forEach((device) => this.d.host.drop(this.id, device))
      this.d.host.greet(this.d.local)
      // Never wait for the old link: over a dead network its close can hang for minutes.
      void old?.close().catch(() => undefined)
      void conn.closed().then(() => {
        if (this.conn === conn && !this.stopped) this.schedule(RETRY_SEC[0]!, 'connection lost')
      })
      this.schedule(Math.max(10, token.exp - this.d.now() - RENEW_BEFORE_SEC), 'token renewal')
      this.log.info('relay: peer connected', {
        peer: this.id,
        kind: this.d.local.kind,
        org: this.d.local.org,
        pairs: token.pairs.length,
        why,
      })
    } catch (err) {
      const wait = RETRY_SEC[Math.min(this.failures++, RETRY_SEC.length - 1)]!
      this.problem = String(err)
      this.log.warn('relay: peer connection failed', {
        peer: this.id,
        err: String(err),
        retryInSec: wait,
      })
      this.schedule(wait, 'retry')
    }
  }

  private schedule(sec: number, why: string): void {
    if (this.stopped) return
    if (this.timer) clearTimeout(this.timer)
    // A day at most: a far-off expiry must not overflow the timer into an instant retry loop.
    this.timer = setTimeout(() => void this.reconnect(why), Math.min(sec, 86_400) * 1000)
  }

  private subscribe(conn: RelayConn, token: RelayToken): void {
    for (const device of token.pairs) {
      conn.subscribe(inboxSubject(this.id, device), {
        callback: (_e, m) =>
          void this.d.host
            .onFrame(this.d.local, m.subject, m.data)
            .catch((err: unknown) => this.log.error('relay: frame failed', { err: String(err) })),
      })
    }
    conn.subscribe(ctrlSubject(this.id), { callback: (_e, m) => void this.control(m.data) })
  }

  // A phone asked the gateway for this demo install's pairing link (#657): a fresh offer, its
  // link back through the gateway to the phone's inbox. Not a demo — the phone hears nothing.
  private async demoRequest(reply: string): Promise<void> {
    if (!this.d.demo || !reply) return
    try {
      const link = await this.d.demo()
      if (!link) return
      // `reply` of a command is this peer's own inbox (request() sets it); the guest's goes as `to`.
      const got = await this.request('demo_link', { to: reply, link })
      if (!got.ok)
        this.log.warn('relay: the gateway refused a demo link', { peer: this.id, error: got.error })
    } catch (err) {
      this.log.warn('relay: a demo request failed', { peer: this.id, err: String(err) })
    }
  }

  private async control(data: Uint8Array): Promise<void> {
    let m: Record<string, unknown>
    try {
      m = JSON.parse(fromUtf8(data)) as Record<string, unknown>
    } catch {
      return
    }
    const s = (k: string): string => String(m[k] ?? '')
    if (m.type === 'pairs-changed') return this.reconnect('pairs changed')
    if (m.type === 'pair-claim')
      return this.d.engine.onClaim(s('offerId'), s('claimId'), s('sealed'))
    if (m.type === 'pair-reveal')
      return this.d.engine.onReveal(s('offerId'), s('claimId'), s('reveal'))
    if (m.type === 'demo-request') return this.demoRequest(s('reply'))
    if (m.type === 'limit')
      this.log.warn('relay: the middleware limited this peer', { peer: this.id, code: m.code })
  }
}

/** What an install or a machine registers with: who it is to the gateway, and its standing. */
export interface Registration {
  kind: 'install' | 'machine'
  display: string
  /** An install's licence token; a machine has none. */
  license?: string
  policy?: { pairingDisabled: boolean }
  /** A machine signed into an install names it (its relay peer id): that home's policy applies. */
  home?: string
  /** A demo install (#657): the gateway forwards phones' demo requests to it. */
  demo?: boolean
}

/** A peer token from the gateway: one short guest connection, the registration (the licence says
 *  which install it is, the signature that it holds the key), the answer, the connection closed. */
export async function registerPeer(
  identity: Identity,
  reg: Registration,
  connect: (token: string) => Promise<RelayConn>,
  nowMs: number,
  random: Random = systemRandom,
): Promise<RelayToken> {
  const gid = b64u(random(16))
  const conn = await connect(`relay-guest.${gid}`)
  try {
    const reply = `relay.reply.${gid}.register`
    const answer = new Promise<Reply>((resolve, reject) => {
      const timer = setTimeout(
        () => reject(new Error('the gateway did not answer the registration')),
        15_000,
      )
      const sub = conn.subscribe(reply, {
        callback: (_e, m) => {
          clearTimeout(timer)
          sub.unsubscribe()
          resolve(JSON.parse(fromUtf8(m.data)) as Reply)
        },
      })
    })
    const body = {
      reply,
      card: peerCard(identity),
      kind: reg.kind,
      display: reg.display,
      ...(reg.license ? { license: reg.license } : {}),
      ...(reg.policy ? { policy: reg.policy } : {}),
      ...(reg.home ? { home: reg.home } : {}),
      ...(reg.demo ? { demo: true } : {}),
      ...signProof(identity, 'register', nowMs),
    }
    conn.publish(`relay.cmd.register.${gid}`, json(body))
    const got = await answer
    if (!got.ok || typeof got.token !== 'string')
      throw new Error(String(got.error ?? 'registration refused'))
    return {
      token: got.token,
      exp: Number(got.exp),
      pairs: Array.isArray(got.pairs) ? got.pairs.map(String) : [],
    }
  } finally {
    await conn.close().catch(() => undefined)
  }
}
