// What travels inside an envelope. For cabinet installs `cmd`/`args` are the cabinet's existing bus
// commands; for Buff Code — the commands of its mobile API (#639). A payload too big for one frame
// travels as parts (session.ts) — files included; nothing above the session knows the frame size.
// Every inbound payload passes parsePayload: a peer is authenticated, but its input is still input.

import { decodeJson, encodeJson } from './encoding.ts'
import { fail } from './errors.ts'

export interface CommandPayload {
  readonly kind: 'cmd'
  readonly id: string
  readonly cmd: string
  readonly args: unknown
}

export interface ReplyError {
  readonly code: string
  readonly message: string
}

export type ReplyPayload =
  | { readonly kind: 'reply'; readonly id: string; readonly ok: true; readonly result: unknown }
  | { readonly kind: 'reply'; readonly id: string; readonly ok: false; readonly error: ReplyError }

export interface EventPayload {
  readonly kind: 'event'
  readonly stream: string
  readonly record: unknown
}

/** One slice of a payload too big for a frame (session.ts): `idx` of `n`, bytes base64url. */
export interface PartPayload {
  readonly kind: 'part'
  readonly idx: number
  readonly n: number
  readonly data: string
}

export type Payload = CommandPayload | ReplyPayload | EventPayload | PartPayload

const ID = /^[A-Za-z0-9_-]{1,64}$/
const NAME = /^[a-z][a-z0-9_.:-]{0,127}$/i

export function encodePayload(payload: Payload): Uint8Array {
  return encodeJson(payload)
}

export function decodePayload(bytes: Uint8Array): Payload {
  return parsePayload(decodeJson(bytes))
}

export function parsePayload(value: unknown): Payload {
  const p = record(value)
  switch (p.kind) {
    case 'cmd':
      return { kind: 'cmd', id: id(p.id), cmd: name(p.cmd), args: p.args ?? null }
    case 'reply':
      if (p.ok === true) return { kind: 'reply', id: id(p.id), ok: true, result: p.result ?? null }
      if (p.ok === false)
        return { kind: 'reply', id: id(p.id), ok: false, error: replyError(p.error) }
      return fail('bad-message', 'reply.ok')
    case 'event':
      return { kind: 'event', stream: name(p.stream), record: p.record ?? null }
    case 'part': {
      const n = count(p.n)
      const idx = count(p.idx)
      if (n < 1 || idx >= n) fail('bad-message', 'part index')
      return { kind: 'part', idx, n, data: text(p.data, 256 * 1024) }
    }
    default:
      return fail('bad-message', 'unknown payload kind')
  }
}

function record(value: unknown): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value))
    fail('bad-message', 'not an object')
  return value as Record<string, unknown>
}

function id(value: unknown): string {
  return typeof value === 'string' && ID.test(value) ? value : fail('bad-message', 'id')
}

function name(value: unknown): string {
  return typeof value === 'string' && NAME.test(value) ? value : fail('bad-message', 'name')
}

function text(value: unknown, max: number): string {
  return typeof value === 'string' && value.length <= max
    ? value
    : fail('bad-message', 'text field')
}

function count(value: unknown): number {
  return Number.isSafeInteger(value) && (value as number) >= 0
    ? (value as number)
    : fail('bad-message', 'count')
}

function replyError(value: unknown): ReplyError {
  const e = record(value)
  return { code: name(e.code), message: text(e.message, 4096) }
}
