// Peer identities. Every peer — phone, CE/EE install, Buff Code machine, the SaaS gateway — holds a
// static ed25519 key (identity, signatures) and a static X25519 key (Noise key agreement), both
// derived from one 32-byte seed so a key store keeps a single secret. The peer id is the base64url
// ed25519 public key; the peer card binds the X25519 key to it with a signature, so nobody relaying a
// card (the gateway included) can swap the agreement key.

import { ed25519, x25519 } from '@noble/curves/ed25519.js'
import { hkdf } from '@noble/hashes/hkdf.js'
import { sha256 } from '@noble/hashes/sha2.js'
import { b64u, concat, fromB64uLength, utf8 } from './encoding.ts'
import { fail } from './errors.ts'
import { type Random, systemRandom } from './random.ts'

export interface Identity {
  readonly id: string
  readonly signSecret: Uint8Array
  readonly signPublic: Uint8Array
  readonly dhSecret: Uint8Array
  readonly dhPublic: Uint8Array
}

/** What a peer tells others about itself: id (sign key), agreement key, signature over both. */
export interface PeerCard {
  readonly id: string
  readonly dh: string
  readonly sig: string
}

export interface PeerKeys {
  readonly id: string
  readonly signPublic: Uint8Array
  readonly dhPublic: Uint8Array
}

const SEED_BYTES = 32
const PEER_ID = /^[A-Za-z0-9_-]{43}$/
const CARD_CONTEXT = utf8('buff-peer-card/v1')

export function identityFromSeed(seed: Uint8Array): Identity {
  if (seed.length !== SEED_BYTES) fail('bad-encoding', 'identity seed must be 32 bytes')
  const signSecret = hkdf(sha256, seed, undefined, utf8('buff-identity/v1/sign'), 32)
  const dhSecret = hkdf(sha256, seed, undefined, utf8('buff-identity/v1/dh'), 32)
  const signPublic = ed25519.getPublicKey(signSecret)
  return {
    id: b64u(signPublic),
    signSecret,
    signPublic,
    dhSecret,
    dhPublic: x25519.getPublicKey(dhSecret),
  }
}

export function generateIdentity(random: Random = systemRandom): {
  seed: Uint8Array
  identity: Identity
} {
  const seed = random(SEED_BYTES)
  return { seed, identity: identityFromSeed(seed) }
}

/** Syntactic check only (43 base64url chars = 32 bytes); it also keeps ids safe inside NATS subjects. */
export function isPeerId(value: unknown): value is string {
  if (typeof value !== 'string' || !PEER_ID.test(value)) return false
  try {
    fromB64uLength(value, 32)
    return true
  } catch {
    return false
  }
}

export function peerCard(identity: Identity): PeerCard {
  const sig = ed25519.sign(
    concat(CARD_CONTEXT, identity.signPublic, identity.dhPublic),
    identity.signSecret,
  )
  return { id: identity.id, dh: b64u(identity.dhPublic), sig: b64u(sig) }
}

export function verifyPeerCard(card: unknown): PeerKeys {
  if (typeof card !== 'object' || card === null) fail('bad-message', 'peer card')
  const { id, dh, sig } = card as Record<string, unknown>
  if (!isPeerId(id) || typeof dh !== 'string' || typeof sig !== 'string')
    fail('bad-message', 'peer card')
  const signPublic = fromB64uLength(id, 32)
  const dhPublic = fromB64uLength(dh, 32)
  let valid = false
  try {
    valid = ed25519.verify(
      fromB64uLength(sig, 64),
      concat(CARD_CONTEXT, signPublic, dhPublic),
      signPublic,
    )
  } catch {
    valid = false
  }
  if (!valid) fail('bad-signature', 'peer card signature')
  return { id, signPublic, dhPublic }
}
