// Byte helpers shared by every module: base64url (RFC 4648 §5, no padding), UTF-8, big-endian
// integers. Written out here rather than borrowed from the platform so the phone (Hermes), Node
// and Bun encode identically.

import { fail } from './errors.ts'

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
const LOOKUP = new Map([...ALPHABET].map((c, i) => [c, i]))

export function b64u(bytes: Uint8Array): string {
  let out = ''
  for (let i = 0; i < bytes.length; i += 3) {
    const n = (bytes[i]! << 16) | ((bytes[i + 1] ?? 0) << 8) | (bytes[i + 2] ?? 0)
    const chars = Math.min(4, Math.ceil(((bytes.length - i) * 8) / 6))
    for (let j = 0; j < chars; j++) out += ALPHABET[(n >> (18 - 6 * j)) & 63]
  }
  return out
}

/** Strict decode: rejects foreign characters and non-canonical tails, so one value has one spelling. */
export function fromB64u(text: string): Uint8Array {
  if (text.length % 4 === 1) fail('bad-encoding', 'base64url length')
  const out = new Uint8Array(Math.floor((text.length * 6) / 8))
  let acc = 0
  let bits = 0
  let o = 0
  for (const c of text) {
    const v = LOOKUP.get(c)
    if (v === undefined) fail('bad-encoding', 'base64url character')
    acc = ((acc << 6) | v) & 0xffff
    bits += 6
    if (bits >= 8) {
      bits -= 8
      out[o++] = (acc >> bits) & 255
    }
  }
  if ((acc & ((1 << bits) - 1)) !== 0) fail('bad-encoding', 'base64url padding bits')
  return out
}

/** Decode and require an exact byte length (keys, nonces, ids). */
export function fromB64uLength(text: string, length: number): Uint8Array {
  const bytes = fromB64u(text)
  if (bytes.length !== length) fail('bad-encoding', `expected ${length} bytes`)
  return bytes
}

export function utf8(text: string): Uint8Array {
  return new TextEncoder().encode(text)
}

export function fromUtf8(bytes: Uint8Array): string {
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes)
  } catch {
    return fail('bad-encoding', 'utf-8')
  }
}

export function concat(...parts: Uint8Array[]): Uint8Array {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0))
  let o = 0
  for (const p of parts) {
    out.set(p, o)
    o += p.length
  }
  return out
}

export function u32be(n: number): Uint8Array {
  const out = new Uint8Array(4)
  new DataView(out.buffer).setUint32(0, n)
  return out
}

export function u64be(n: number): Uint8Array {
  if (!Number.isSafeInteger(n) || n < 0) fail('bad-message', 'counter out of range')
  const out = new Uint8Array(8)
  new DataView(out.buffer).setBigUint64(0, BigInt(n))
  return out
}

export function readU32be(bytes: Uint8Array): number {
  return new DataView(bytes.buffer, bytes.byteOffset, 4).getUint32(0)
}

/** Constant-time comparison for secrets and MACs. */
export function equalBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false
  let diff = 0
  for (let i = 0; i < a.length; i++) diff |= a[i]! ^ b[i]!
  return diff === 0
}

/** JSON over UTF-8 — the encoding of every frame, payload and pairing message. */
export function encodeJson(value: unknown): Uint8Array {
  return utf8(JSON.stringify(value))
}

export function decodeJson(bytes: Uint8Array): unknown {
  try {
    return JSON.parse(fromUtf8(bytes))
  } catch {
    return fail('bad-message', 'not JSON')
  }
}
