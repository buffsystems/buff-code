// Protocol versioning: every peer announces the range it speaks in the handshake; the responder picks
// the highest common version or answers «incompatible», which the phone shows as its own screen.

export const PROTOCOL_VERSION = 2

export interface VersionRange {
  readonly min: number
  readonly max: number
}

/** v2 (#739): a payload bigger than a frame goes as parts; v1 peers are not served. */
export const SUPPORTED_VERSIONS: VersionRange = { min: PROTOCOL_VERSION, max: PROTOCOL_VERSION }

export function negotiateVersion(local: VersionRange, remote: VersionRange): number | null {
  const v = Math.min(local.max, remote.max)
  return v >= Math.max(local.min, remote.min) ? v : null
}
