// Messages between relay clients and the gateway backend (#633): command bodies on
// relay.cmd.<op>.<sender>, control messages on relay.ctrl.<peer>, and the proof of key possession
// a peer signs to register or renew its token. The gateway learns the SENDER from the subject;
// a body never names it.
//
// Pairing through the gateway (subjects.ts, pairing.ts):
//   offerer  offer   {offerId, kind, sealed, expiresAt}             → stored, TTL capped
//   claimer  claim   {reply, offerId, sealed}                       → ctrl pair-claim to the offerer
//   offerer  answer  {offerId, claimId, nonce?}                     → claimer's reply: {claimId, sealed, nonce?}
//            answer  {offerId, claimId, refused}  (claim did not open) → claimer's reply: refused
//   claimer  reveal  {offerId, claimId, reveal}   (code only)       → ctrl pair-reveal to the offerer
//   offerer  confirm {offerId, claimId, claimer, display}           → pair recorded; claimer's reply: paired
//   either   revoke  {pairId}                                       → pairs-changed to both

import { ed25519 } from '@noble/curves/ed25519.js'
import { b64u, encodeJson, fromB64uLength } from './encoding.ts'
import { fail } from './errors.ts'
import { type Identity, isPeerId, type PeerCard } from './identity.ts'
import {
  type OfferKind,
  type PairOfferMessage,
  parsePairLink,
  parsePairOffer,
  type PeerKind,
} from './pairing.ts'

/** How far a proof's timestamp may sit from the gateway's clock. */
export const PROOF_SKEW_MS = 5 * 60 * 1000

/** Signed by the peer's ed25519 key: «I hold this id, now, for this command». */
export interface PeerProof {
  readonly ts: number
  readonly sig: string
}

export interface RegisterCommand extends PeerProof {
  readonly reply: string
  readonly card: PeerCard
  readonly kind: Exclude<PeerKind, 'saas'>
  readonly display: string
  /** A Buff Code machine signed into an install names it here (#633: home_install). */
  readonly home?: string
  /** A demo install (#657): phones' demo requests are forwarded to it. */
  readonly demo?: true
}

/** A guest asks a demo install for a pairing link (#657). */
export interface DemoCommand {
  readonly reply: string
  readonly peer: string
}

/** A demo install's answer: a QR pairing link for the guest that asked (#657). `reply` is the
 *  install's own inbox for the gateway's answer; `to` — the guest's, where the link goes. */
export interface DemoLinkCommand {
  readonly reply: string
  readonly to: string
  readonly link: string
  readonly offerId: string
}

export interface TokenCommand extends PeerProof {
  readonly reply: string
  readonly peer: string
}

export interface OfferCommand extends PairOfferMessage {
  readonly reply: string
}

export interface ClaimCommand {
  readonly reply: string
  readonly offerId: string
  readonly sealed: string
}

export interface AnswerCommand {
  readonly offerId: string
  readonly claimId: string
  readonly nonce?: string
  /** The claim did not open: the phone is told at once instead of waiting out its timeout. */
  readonly refused?: 'wrong-code'
}

export interface RevealCommand {
  readonly offerId: string
  readonly claimId: string
  readonly reveal: string
}

export interface ConfirmCommand {
  readonly reply: string
  readonly offerId: string
  readonly claimId: string
  readonly claimer: string
  readonly display: string
  /** Who paired the phone, for the phone's «paired» screen (display only — rights stay on the install). */
  readonly user?: string
}

export interface RevokeCommand {
  readonly reply: string
  readonly pairId: string
}

/** A provider publishes a share link (#815): the gateway records who to ask for `id`. `expiresAt`
 *  (ms) lets the gateway forget the entry by itself; absent — until revoked. */
export interface SharePublishCommand {
  readonly reply: string
  readonly id: string
  readonly expiresAt?: number
}

/** The link ended at the provider (deleted, or its source is gone): the gateway forgets it. */
export interface ShareRevokeCommand {
  readonly reply: string
  readonly id: string
}

/** What the claimer hears on its claim's reply subject, in order. */
export type ClaimEvent =
  | {
      readonly type: 'claimed'
      readonly claimId: string
      readonly sealed: string
      readonly nonce?: string
    }
  | {
      readonly type: 'paired'
      readonly pairId: string
      readonly peer: string
      readonly token: string
      readonly exp: number
      readonly user?: string
    }
  | { readonly type: 'refused'; readonly code: string }

/** Control messages on relay.ctrl.<peer>. */
export type ControlMessage =
  | {
      readonly type: 'pairs-changed'
      readonly ver: number
      readonly kick?: boolean
      readonly reason?: string
    }
  | {
      readonly type: 'pair-claim'
      readonly offerId: string
      readonly claimId: string
      readonly sealed: string
    }
  | {
      readonly type: 'pair-reveal'
      readonly offerId: string
      readonly claimId: string
      readonly reveal: string
    }
  | { readonly type: 'limit'; readonly code: string }
  | { readonly type: 'demo-request'; readonly reply: string }

const TOKEN = /^[A-Za-z0-9_-]{22}$/
const REPLY = /^relay\.reply\.[A-Za-z0-9_-]{22,43}\.[A-Za-z0-9_.-]{1,64}$/
const PEER_KINDS = new Set(['device', 'install', 'machine'])

export function signProof(identity: Identity, command: string, ts: number): PeerProof {
  return { ts, sig: b64u(ed25519.sign(proofBytes(command, identity.id, ts), identity.signSecret)) }
}

/** Throws bad-signature unless `peer` signed this command at a time within PROOF_SKEW_MS of `now`. */
export function verifyProof(peer: string, command: string, proof: PeerProof, now: number): void {
  if (!isPeerId(peer)) fail('bad-peer-id', 'proof peer')
  if (!Number.isSafeInteger(proof.ts) || Math.abs(now - proof.ts) > PROOF_SKEW_MS) {
    fail('bad-signature', 'proof timestamp out of range')
  }
  let ok = false
  try {
    ok = ed25519.verify(
      fromB64uLength(proof.sig, 64),
      proofBytes(command, peer, proof.ts),
      fromB64uLength(peer, 32),
    )
  } catch {
    ok = false
  }
  if (!ok) fail('bad-signature', 'proof signature')
}

/** The reply subject must sit under the sender's own prefix — the gateway never answers elsewhere. */
export function replyBelongsTo(reply: string, sender: string): boolean {
  return REPLY.test(reply) && reply.startsWith(`relay.reply.${sender}.`)
}

export function parseRegister(value: unknown): RegisterCommand {
  const m = obj(value)
  if (!PEER_KINDS.has(String(m.kind))) fail('bad-message', 'register kind')
  if (m.home !== undefined && !isPeerId(m.home)) fail('bad-peer-id', 'home')
  const base = {
    reply: reply(m.reply),
    card: card(m.card),
    kind: m.kind as RegisterCommand['kind'],
    display: text(m.display, 128),
    ...proof(m),
  }
  const withHome = m.home === undefined ? base : { ...base, home: m.home as string }
  return m.demo === true ? { ...withHome, demo: true } : withHome
}

export function parseDemo(value: unknown): DemoCommand {
  const m = obj(value)
  if (!isPeerId(m.peer)) fail('bad-peer-id', 'peer')
  return { reply: reply(m.reply), peer: m.peer }
}

/** Only a QR link — its secret lets the phone claim with no code; the offer must be the sender's. */
export function parseDemoLink(value: unknown): DemoLinkCommand {
  const m = obj(value)
  const link = typeof m.link === 'string' ? m.link : fail('bad-message', 'link')
  const parsed = parsePairLink(link)
  if (!parsed.secret) fail('bad-message', 'a demo link is a QR one')
  return { reply: reply(m.reply), to: reply(m.to), link, offerId: parsed.offerId }
}

export function parseToken(value: unknown): TokenCommand {
  const m = obj(value)
  if (!isPeerId(m.peer)) fail('bad-peer-id', 'peer')
  return { reply: reply(m.reply), peer: m.peer, ...proof(m) }
}

export function parseOffer(value: unknown): OfferCommand {
  const m = obj(value)
  return { ...parsePairOffer(m), reply: reply(m.reply) }
}

export function parseClaim(value: unknown): ClaimCommand {
  const m = obj(value)
  return { reply: reply(m.reply), offerId: token(m.offerId), sealed: sealed(m.sealed) }
}

export function parseAnswer(value: unknown): AnswerCommand {
  const m = obj(value)
  const base = { offerId: token(m.offerId), claimId: token(m.claimId) }
  if (m.refused !== undefined) {
    if (m.refused !== 'wrong-code') fail('bad-message', 'answer refused')
    return { ...base, refused: 'wrong-code' }
  }
  return m.nonce === undefined
    ? base
    : { ...base, nonce: b64u(fromB64uLength(String(m.nonce), 16)) }
}

export function parseReveal(value: unknown): RevealCommand {
  const m = obj(value)
  return {
    offerId: token(m.offerId),
    claimId: token(m.claimId),
    reveal: b64u(fromB64uLength(String(m.reveal), 16)),
  }
}

export function parseConfirm(value: unknown): ConfirmCommand {
  const m = obj(value)
  if (!isPeerId(m.claimer)) fail('bad-peer-id', 'claimer')
  const base = {
    reply: reply(m.reply),
    offerId: token(m.offerId),
    claimId: token(m.claimId),
    claimer: m.claimer,
    display: text(m.display, 128),
  }
  return m.user === undefined ? base : { ...base, user: text(m.user, 128) }
}

export function parseRevoke(value: unknown): RevokeCommand {
  const m = obj(value)
  return { reply: reply(m.reply), pairId: token(m.pairId) }
}

export function parseSharePublish(value: unknown): SharePublishCommand {
  const m = obj(value)
  const base = { reply: reply(m.reply), id: token(m.id) }
  if (m.expiresAt === undefined || m.expiresAt === null) return base
  if (!Number.isSafeInteger(m.expiresAt) || (m.expiresAt as number) <= 0)
    fail('bad-message', 'expiresAt')
  return { ...base, expiresAt: m.expiresAt as number }
}

export function parseShareRevoke(value: unknown): ShareRevokeCommand {
  const m = obj(value)
  return { reply: reply(m.reply), id: token(m.id) }
}

/** The kinds of offer a gateway accepts, re-exported for its validation. */
export const OFFER_KINDS: readonly OfferKind[] = ['qr', 'code']

function proofBytes(command: string, peer: string, ts: number): Uint8Array {
  return encodeJson(['buff-relay-proof/v1', command, peer, ts])
}

function proof(m: Record<string, unknown>): PeerProof {
  if (!Number.isSafeInteger(m.ts) || typeof m.sig !== 'string') fail('bad-message', 'proof')
  return { ts: m.ts as number, sig: m.sig }
}

function card(value: unknown): PeerCard {
  const c = obj(value)
  if (!isPeerId(c.id) || typeof c.dh !== 'string' || typeof c.sig !== 'string') {
    fail('bad-message', 'card')
  }
  return { id: c.id, dh: c.dh, sig: c.sig }
}

function obj(value: unknown): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    fail('bad-message', 'not an object')
  }
  return value as Record<string, unknown>
}

function reply(value: unknown): string {
  return typeof value === 'string' && REPLY.test(value) ? value : fail('bad-message', 'reply')
}

function token(value: unknown): string {
  return typeof value === 'string' && TOKEN.test(value) ? value : fail('bad-message', 'id')
}

function sealed(value: unknown): string {
  return typeof value === 'string' && value.length <= 8192 ? value : fail('bad-message', 'sealed')
}

function text(value: unknown, max: number): string {
  return typeof value === 'string' && value.length <= max ? value : fail('bad-message', 'text')
}
