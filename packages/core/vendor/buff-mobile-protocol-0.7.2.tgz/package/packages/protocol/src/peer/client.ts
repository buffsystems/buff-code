// The asking side of a peer session (#815): what a phone does by hand today, as one class — the
// gateway's share viewer runs it to ask any provider for a link's content. One connection, one
// wildcard subscription for frames to itself; per remote peer a Noise KK session opened on first
// use (the client is the initiator), commands sealed and matched to their replies by id.
//
// A remote that holds no session with us (it restarted) answers `rst`: the session is dropped and
// the next request shakes hands again. The token is renewed before it expires and the connection
// reopened; sessions survive that — they live in memory on both ends, not in the socket.

import { fromB64uLength, utf8 } from '../encoding.ts'
import { ProtocolError } from '../errors.ts'
import { decodeFrame, type HandshakeFrame } from '../frames.ts'
import type { Identity, PeerKeys } from '../identity.ts'
import type { ReplyError } from '../payload.ts'
import { systemRandom, type Random } from '../random.ts'
import { finishHandshake, startHandshake, type PendingHandshake, type Session } from '../session.ts'
import { inboxSubject } from '../subjects.ts'
import { silentLog, type PeerLog } from './common.ts'
import type { RelayConn } from './link.ts'

export interface ClientToken {
  token: string
  exp: number
}

export interface ClientDeps {
  local: Identity
  token(): Promise<ClientToken>
  connect(token: string): Promise<RelayConn>
  /** Seconds. */
  now(): number
  random?: Random
  log?: PeerLog
  /** An event a remote pushed over its session (a live share, #823). */
  onEvent?(peer: string, stream: string, record: unknown): void
  /** How long a remote has to answer hello before it counts as offline. */
  handshakeMs?: number
}

export type ClientResult = { ok: true; result: unknown } | { ok: false; error: ReplyError }

const RENEW_BEFORE_SEC = 120
const RETRY_SEC = [2, 5, 15, 30, 60]
const json = (v: unknown): Uint8Array => utf8(JSON.stringify(v))

/** Whom to ask: a peer's id and agreement key, as the gateway's registry keeps them — the card was
 *  verified when the peer registered, so no signature travels here again. */
export interface PeerAddress {
  readonly id: string
  readonly dh: string
}

interface Remote {
  address: PeerAddress
  session?: Session
  pending?: { handshake: PendingHandshake; done: Promise<Session> }
}

export class RelayClient {
  private conn: RelayConn | null = null
  private readonly remotes = new Map<string, Remote>()
  private readonly waiting = new Map<string, (r: ClientResult) => void>()
  private timer: ReturnType<typeof setTimeout> | null = null
  private failures = 0
  private seq = 0
  private stopped = false
  readonly d: ClientDeps
  private readonly log: PeerLog
  private readonly random: Random

  constructor(deps: ClientDeps) {
    this.d = deps
    this.log = deps.log ?? silentLog
    this.random = deps.random ?? systemRandom
  }

  get id(): string {
    return this.d.local.id
  }

  get connected(): boolean {
    return this.conn !== null
  }

  async start(): Promise<void> {
    this.stopped = false
    await this.reconnect('start')
  }

  async stop(): Promise<void> {
    this.stopped = true
    if (this.timer) clearTimeout(this.timer)
    await this.conn?.close().catch(() => undefined)
    this.conn = null
  }

  /**
   * One command to `remote`; its session is opened first when there is none. A remote that does
   * not answer hello in time, or the command in `timeoutMs`, reads as `offline` / `timeout`.
   */
  async request(
    remote: PeerAddress,
    cmd: string,
    args: unknown,
    timeoutMs = 20_000,
  ): Promise<ClientResult> {
    const conn = this.conn
    if (!conn) return refused('offline', 'the relay is not connected')
    let session: Session
    try {
      session = await this.open(conn, remote)
    } catch (err) {
      const code = err instanceof ProtocolError ? err.code : 'offline'
      return refused(code, err instanceof Error ? err.message : String(err))
    }
    const id = `c${++this.seq}`
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.waiting.delete(id)
        resolve(refused('timeout', 'the peer did not answer'))
      }, timeoutMs)
      this.waiting.set(id, (r) => {
        clearTimeout(timer)
        resolve(r)
      })
      try {
        const subject = inboxSubject(remote.id, this.id)
        for (const bytes of session.seal({ kind: 'cmd', id, cmd, args }))
          conn.publish(subject, bytes)
      } catch (err) {
        clearTimeout(timer)
        this.waiting.delete(id)
        resolve(refused(err instanceof ProtocolError ? err.code : 'internal', String(err)))
      }
    })
  }

  /** Forget a remote's session (it was revoked, or we want a fresh hello next time). */
  forget(peer: string): void {
    this.remotes.delete(peer)
  }

  private readonly settlers = new Map<string, (session: Session | null, err?: Error) => void>()

  private open(conn: RelayConn, address: PeerAddress): Promise<Session> {
    const known = this.remotes.get(address.id)
    if (known?.session) return Promise.resolve(known.session)
    if (known?.pending) return known.pending.done
    const remote: Remote = known ?? { address }
    this.remotes.set(address.id, remote)
    const handshake = startHandshake({
      local: this.d.local,
      remote: keysOf(address),
      random: this.random,
    })
    const done = new Promise<Session>((resolve, reject) => {
      const settle = (session: Session | null, err?: Error): void => {
        clearTimeout(timer)
        if (remote.pending?.handshake !== handshake) return
        remote.pending = undefined
        this.settlers.delete(address.id)
        if (session) {
          remote.session = session
          resolve(session)
        } else reject(err ?? new Error('handshake failed'))
      }
      const timer = setTimeout(
        () => settle(null, new Error('the peer did not answer hello')),
        this.d.handshakeMs ?? 8_000,
      )
      this.settlers.set(address.id, settle)
    })
    remote.pending = { handshake, done }
    conn.publish(inboxSubject(address.id, this.id), json(handshake.frame))
    return done
  }

  private frame(subject: string, data: Uint8Array): void {
    const from = subject.split('.')[3] ?? ''
    const remote = this.remotes.get(from)
    if (!remote) return
    try {
      const frame = decodeFrame(data)
      if (frame.from !== from || frame.to !== this.id) return
      if (frame.t === 'rst') {
        // The remote restarted: whatever we hold is gone; the next request says hello again.
        remote.session = undefined
        return
      }
      if (frame.t === 'hs2') {
        if (!remote.pending) return
        const session = finishHandshake(remote.pending.handshake, frame as HandshakeFrame)
        this.settlers.get(from)?.(session)
        return
      }
      if (frame.t !== 'msg' || !remote.session) return
      const p = remote.session.open(frame)
      if (!p) return // a part of a payload still arriving
      if (p.kind === 'event') this.d.onEvent?.(from, p.stream, p.record)
      else if (p.kind === 'reply') {
        const done = this.waiting.get(p.id)
        this.waiting.delete(p.id)
        done?.(p.ok ? { ok: true, result: p.result } : { ok: false, error: p.error })
      }
    } catch (err) {
      const e = err instanceof Error ? err : new Error(String(err))
      if (remote.pending) this.settlers.get(from)?.(null, e)
      this.log.warn('relay client: frame refused', {
        from,
        code: err instanceof ProtocolError ? err.code : String(err),
      })
    }
  }

  private async reconnect(why: string): Promise<void> {
    if (this.stopped) return
    if (this.timer) clearTimeout(this.timer)
    try {
      const token = await this.d.token()
      const conn = await this.d.connect(token.token)
      conn.subscribe(`relay.${this.id}.in.*`, {
        callback: (_e, m) => this.frame(m.subject, m.data),
      })
      const old = this.conn
      ;[this.conn, this.failures] = [conn, 0]
      void old?.close().catch(() => undefined)
      void conn.closed().then(() => {
        if (this.conn === conn && !this.stopped) this.schedule(RETRY_SEC[0]!, 'connection lost')
      })
      this.schedule(Math.max(10, token.exp - this.d.now() - RENEW_BEFORE_SEC), 'token renewal')
      this.log.info('relay client: connected', { peer: this.id, why })
    } catch (err) {
      const wait = RETRY_SEC[Math.min(this.failures++, RETRY_SEC.length - 1)]!
      this.log.warn('relay client: connection failed', {
        peer: this.id,
        err: String(err),
        retryInSec: wait,
      })
      this.schedule(wait, 'retry')
    }
  }

  private schedule(sec: number, why: string): void {
    if (this.stopped) return
    if (this.timer) clearTimeout(this.timer)
    this.timer = setTimeout(() => void this.reconnect(why), Math.min(sec, 86_400) * 1000)
  }
}

function keysOf(address: PeerAddress): PeerKeys {
  return {
    id: address.id,
    signPublic: fromB64uLength(address.id, 32),
    dhPublic: fromB64uLength(address.dh, 32),
  }
}

function refused(code: string, message: string): ClientResult {
  return { ok: false, error: { code, message } }
}
