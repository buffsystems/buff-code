// Share links (#815, epic #769): the contract between the gateway's viewer and a provider. The
// content of a link is NEVER kept at buff.systems — the gateway only knows which provider holds
// `id`; the page asks, the provider answers from its own store, with the link's own rules
// (password, expiry, what it shows). A provider serves the viewer these commands and nothing else.
//
//   share.view {id, pass?, after?, limit?, sub?} → ShareAnswer: a document page, or why there is none
//   share.file {id, pass?, file, from?}     → one chunk of an attachment (base64), `next` = offset or null
//
// Every inbound argument passes its parser: the viewer is a known peer, but its input is still input.

import { b64u } from './encoding.ts'
import { fail } from './errors.ts'
import { type Random, systemRandom } from './random.ts'

export const SHARE_VIEW = 'share.view'
export const SHARE_FILE = 'share.file'
/** The commands a provider answers the viewer — its whole surface to the viewer. */
export const SHARE_COMMANDS: readonly string[] = [SHARE_VIEW, SHARE_FILE]

/** Items per page by default and at most; `after` is the id of the last item of the previous page. */
export const SHARE_PAGE = { limit: 50, max: 200 } as const
/** A file chunk: base64 of this many bytes at most (fits a frame with room for the envelope). */
export const SHARE_FILE_CHUNK = 96 * 1024

export interface ShareViewArgs {
  readonly id: string
  readonly pass?: string
  readonly after?: string
  readonly limit: number
  /** The last `limit` items instead of the first (#823): a live page lands where the dialog is now. */
  readonly tail?: true
  /**
   * A subagent's own session instead of the link's (#893): the id a subagent call of the document
   * names (`session`). The provider answers only for a descendant of the shared session.
   */
  readonly sub?: string
}

export interface ShareFileArgs {
  readonly id: string
  readonly pass?: string
  readonly file: string
  readonly from: number
}

/** Why a link shows no document. `password` — one is needed (or the given one is wrong). */
export type ShareRefusal = 'missing' | 'deleted' | 'expired' | 'disabled' | 'password'

export type ShareKind = 'session' | 'messages' | 'ask' | 'research'

export interface ShareFile {
  readonly id: string
  readonly name: string
  readonly mime: string
  readonly size: number
}

export type SharePart =
  | { readonly kind: 'text'; readonly text: string }
  | { readonly kind: 'reasoning'; readonly text: string }
  | {
      readonly kind: 'tool'
      readonly name: string
      readonly title: string
      readonly status: 'running' | 'done' | 'error'
      readonly input?: string
      readonly output?: string
      /** A subagent call (#893): its own session, readable with `sub` while the link shows tools. */
      readonly session?: string
    }
  /** `note` (#892): what the agent said when it handed the file over («a file for you»). */
  | { readonly kind: 'file'; readonly file: ShareFile; readonly note?: string }
  /**
   * A line of the session that is neither the person's nor the model's words (#892): a goal or a
   * workflow notice, a failed turn (`tone: 'error'`). `summary` unfolds under the label.
   */
  | {
      readonly kind: 'notice'
      readonly label: string
      readonly summary?: string
      readonly tone?: 'error'
    }

export interface ShareItem {
  readonly id: string
  readonly role: 'user' | 'assistant' | 'system'
  /** Epoch ms. */
  readonly at: number
  readonly parts: readonly SharePart[]
}

/** One page of a shared document, as the page renders it. */
export interface ShareDocument {
  readonly title: string
  readonly kind: ShareKind
  /** Whether tool calls and their results are shown — the link's own setting. */
  readonly tools: boolean
  /** The source still changes (a session being worked on): the page may follow it. */
  readonly live: boolean
  /** The source is being worked on right now (#823): a live page keeps asking while this holds. */
  readonly active?: boolean
  /** Epoch ms when the link was made; `expiresAt` when it ends by itself. */
  readonly createdAt: number
  readonly expiresAt: number | null
  readonly items: readonly ShareItem[]
  readonly next: string | null
  /**
   * The document is a subagent's own session (#893): the `sub` that was asked for. A viewer that
   * asked for one and got a document without it reached a provider or a gateway that does not
   * know `sub` — that is the link's session, not the subagent's.
   */
  readonly sub?: string
}

export type ShareAnswer =
  | { readonly ok: true; readonly document: ShareDocument }
  | { readonly ok: true; readonly refused: ShareRefusal }

export interface ShareFileChunk {
  readonly file: ShareFile
  readonly data: string
  readonly from: number
  readonly next: number | null
}

const ID = /^[A-Za-z0-9_-]{22}$/
const FILE_ID = /^[A-Za-z0-9_.:-]{1,128}$/
const PASS_MAX = 256

/** A fresh link id: 16 random bytes, 22 base64url characters — a subject-safe token. */
export function newShareId(random: Random = systemRandom): string {
  return b64u(random(16))
}

export function isShareId(value: unknown): value is string {
  return typeof value === 'string' && ID.test(value)
}

export function parseShareViewArgs(value: unknown): ShareViewArgs {
  const m = obj(value)
  const limit =
    m.limit === undefined
      ? SHARE_PAGE.limit
      : Number.isSafeInteger(m.limit) && (m.limit as number) > 0
        ? Math.min(m.limit as number, SHARE_PAGE.max)
        : fail('bad-message', 'limit')
  return {
    id: id(m.id),
    ...pass(m.pass),
    ...(m.after === undefined ? {} : { after: text(m.after, 128, 'after') }),
    limit,
    ...(m.tail === true ? { tail: true } : {}),
    ...(m.sub === undefined ? {} : { sub: sessionId(m.sub) }),
  }
}

export function parseShareFileArgs(value: unknown): ShareFileArgs {
  const m = obj(value)
  const file =
    typeof m.file === 'string' && FILE_ID.test(m.file) ? m.file : fail('bad-message', 'file')
  const from =
    m.from === undefined
      ? 0
      : Number.isSafeInteger(m.from) && (m.from as number) >= 0
        ? (m.from as number)
        : fail('bad-message', 'from')
  return { id: id(m.id), ...pass(m.pass), file, from }
}

const SESSION_ID = /^[A-Za-z0-9_-]{1,64}$/

function sessionId(value: unknown): string {
  return typeof value === 'string' && SESSION_ID.test(value) ? value : fail('bad-message', 'sub')
}

function pass(value: unknown): { pass?: string } {
  if (value === undefined || value === null || value === '') return {}
  return { pass: text(value, PASS_MAX, 'pass') }
}

function id(value: unknown): string {
  return isShareId(value) ? value : fail('bad-message', 'share id')
}

function text(value: unknown, max: number, what: string): string {
  return typeof value === 'string' && value.length <= max ? value : fail('bad-message', what)
}

function obj(value: unknown): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value))
    fail('bad-message', 'not an object')
  return value as Record<string, unknown>
}
