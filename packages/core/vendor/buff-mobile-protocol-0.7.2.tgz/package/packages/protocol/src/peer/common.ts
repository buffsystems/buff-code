// The peer side of the relay (#634, #639) — what an install, a SaaS org at buff.systems or a Buff
// Code machine runs to serve paired phones. Shared by the auth-worker and Buff Code: one
// implementation of the security-critical part. Sockets, storage and logging are the caller's.

/** A gateway's or a command's answer: `ok`, and what the command returns or why it refused. */
export interface Reply {
  ok: boolean
  error?: unknown
  [key: string]: unknown
}

/** A refusal the phone or the person may read as it is (a missing right, an expired pairing). */
export class RefusalError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'RefusalError'
  }
}

export interface PeerLog {
  info(message: string, fields?: Record<string, unknown>): void
  warn(message: string, fields?: Record<string, unknown>): void
  error(message: string, fields?: Record<string, unknown>): void
}

export const silentLog: PeerLog = { info() {}, warn() {}, error() {} }

/** For whom a phone acts on this peer — recorded when the pairing was confirmed. */
export interface DeviceGrant {
  login: string
  /** The org the pairing was made in; none for an install-wide or a machine pairing. */
  org: string | null
  /** Paired with a demo install's demo offer (#657): read only, whatever the login may do. */
  demo?: boolean
  /** The gateway's share viewer (#815): no person behind it — it may ask share commands only. */
  viewer?: boolean
}
