// The peer's side of the phone sessions (#634): frames from paired phones in, frames back out. Pure —
// the link feeds it subjects and bytes and sends what it publishes.
//
// Every frame is checked against the pairing as it is NOW: the sender is the subject's last token
// (pinned by the middleware), it must be in the local peer's current pairs (its relay token) and
// have an active device record here. A revoked phone loses its session with its next frame,
// whatever it still holds. A frame of a session this process does not hold (it restarted) gets a
// reset, and the phone shakes hands again.

import { fromB64uLength, utf8 } from '../encoding.ts'
import { ProtocolError } from '../errors.ts'
import { decodeFrame, type HandshakeFrame } from '../frames.ts'
import type { Identity, PeerCard } from '../identity.ts'
import type { Payload } from '../payload.ts'
import { acceptHandshake, type Session } from '../session.ts'
import { inboxSubject, parseInboxSubject } from '../subjects.ts'
import { RefusalError, silentLog, type DeviceGrant, type PeerLog, type Reply } from './common.ts'

/** A peer answering phones: an install, a SaaS org (at buff.systems) or a Buff Code machine. */
export interface LocalPeer {
  identity: Identity
  kind: 'install' | 'saas' | 'machine'
  org: string | null
}

/** A phone paired with a local peer, as recorded at confirmation. */
export interface DeviceRecord extends DeviceGrant {
  peer: string
  device: string
  dh: string
  display: string
  pairId: string
  created: number
  revoked?: number
}

export interface HostPorts {
  device(peer: string, device: string): Promise<DeviceRecord | null>
  /** The local peer's active pairs as its current relay token states them. */
  pairs(peer: string): readonly string[]
  exec(grant: DeviceRecord, op: string, args: unknown): Promise<Reply>
  publish(subject: string, bytes: Uint8Array): void
  log?: PeerLog
}

const key = (peer: string, device: string): string => `${peer}|${device}`

export class RelayHost {
  private readonly sessions = new Map<string, Session>()
  /** The gateway's share viewer per local peer (#815), as the peer's last token named it. */
  private readonly viewers = new Map<string, PeerCard>()
  /** When each phone was last heard (epoch seconds): who is «on the line». */
  private readonly heard = new Map<string, number>()
  /** Each phone's frames in the order they arrived: a session opens only a growing seq. */
  private readonly turns = new Map<string, Promise<unknown>>()
  readonly ports: HostPorts
  private readonly log: PeerLog

  constructor(ports: HostPorts) {
    this.ports = ports
    this.log = ports.log ?? silentLog
  }

  /** The link learned (or lost) the viewer's card with its token: the host answers it from now on. */
  setViewer(peer: string, card: PeerCard | null): void {
    if (card) this.viewers.set(peer, card)
    else this.viewers.delete(peer)
  }

  /** The phones holding a live session right now. */
  sessionList(): { peer: string; device: string }[] {
    return [...this.sessions.keys()].map((k) => {
      const [peer = '', device = ''] = k.split('|')
      return { peer, device }
    })
  }

  /** An event to a phone over its live session; a payload over what the phone takes is dropped
   *  with a note — the phone reads it on its next open. */
  push(peer: string, device: string, payload: Payload): void {
    const session = this.sessions.get(key(peer, device))
    if (!session) return
    try {
      this.send(device, peer, session, payload)
    } catch (err) {
      this.log.warn('relay: event not sent', {
        device,
        code: err instanceof ProtocolError ? err.code : String(err),
      })
    }
  }

  /** One payload to a phone: every frame of it, in order. */
  private send(device: string, peer: string, session: Session, payload: Payload): void {
    const subject = inboxSubject(device, peer)
    for (const bytes of session.seal(payload)) this.ports.publish(subject, bytes)
  }

  seen(peer: string, device: string): number | null {
    return this.heard.get(key(peer, device)) ?? null
  }

  /** The phone's live session ends now (revoked, policy, teardown). */
  drop(peer: string, device: string): void {
    this.sessions.delete(key(peer, device))
  }

  /** Just (re)connected: every paired phone without a session here is asked to say hello — after a
   *  restart its old session is gone, and a fresh pair may have spoken too early. */
  greet(local: LocalPeer): void {
    for (const device of this.ports.pairs(local.identity.id))
      if (!this.sessions.has(key(local.identity.id, device))) this.reset(local, device)
  }

  async onFrame(local: LocalPeer, subject: string, bytes: Uint8Array): Promise<void> {
    const route = parseInboxSubject(subject)
    if (!route || route.to !== local.identity.id) return
    // Opened one by one, or a burst overtakes itself across the lookups and reads as a replay;
    // the command then runs on its own, so a slow one holds no one behind it.
    const k = key(local.identity.id, route.from)
    const turn = (this.turns.get(k) ?? Promise.resolve()).then(() =>
      this.receive(local, route.from, bytes),
    )
    const settled = turn.catch(() => undefined)
    this.turns.set(k, settled)
    void settled.then(() => this.turns.get(k) === settled && this.turns.delete(k))
    const run = await turn
    await run?.()
  }

  private async receive(
    local: LocalPeer,
    from: string,
    bytes: Uint8Array,
  ): Promise<(() => Promise<void>) | undefined> {
    const record = await this.paired(local, from)
    if (!record) {
      this.drop(local.identity.id, from)
      return
    }
    let frame
    try {
      frame = decodeFrame(bytes)
    } catch (err) {
      this.log.warn('relay: undecodable frame', { from: from, err: String(err) })
      return
    }
    if (frame.from !== from) return // the subject names the sender; a frame cannot claim another
    this.heard.set(key(local.identity.id, from), Math.floor(Date.now() / 1000))
    if (frame.t === 'hs1') {
      this.handshake(local, record, frame)
      return
    }
    if (frame.t !== 'msg') return
    const session = this.sessions.get(key(local.identity.id, from))
    if (!session) {
      this.reset(local, from) // a session from before a restart
      return
    }
    let payload: Payload | null
    try {
      payload = session.open(frame)
    } catch (err) {
      // Not a phone's honest mistake: a wrong key or a replay — the signal of an attack.
      this.log.warn('relay: frame refused', {
        from: from,
        code: err instanceof ProtocolError ? err.code : String(err),
      })
      return
    }
    if (payload?.kind !== 'cmd') return
    const { id, cmd, args } = payload
    return () => this.command(local, record, session, id, cmd, args)
  }

  private async paired(local: LocalPeer, device: string): Promise<DeviceRecord | null> {
    if (!this.ports.pairs(local.identity.id).includes(device)) return null
    // The share viewer (#815) is no phone: no record here, its card came with the token.
    const viewer = this.viewers.get(local.identity.id)
    if (viewer && viewer.id === device) return viewerRecord(local.identity.id, viewer)
    const record = await this.ports.device(local.identity.id, device)
    return record && !record.revoked ? record : null
  }

  private reset(local: LocalPeer, device: string): void {
    const frame = { t: 'rst', from: local.identity.id, to: device }
    this.ports.publish(inboxSubject(device, local.identity.id), utf8(JSON.stringify(frame)))
  }

  private handshake(local: LocalPeer, record: DeviceRecord, frame: HandshakeFrame): void {
    try {
      const remote = {
        id: record.device,
        signPublic: fromB64uLength(record.device, 32),
        dhPublic: fromB64uLength(record.dh, 32),
      }
      const { frame: reply, session } = acceptHandshake({ local: local.identity, remote }, frame)
      if (session) {
        this.sessions.set(key(local.identity.id, record.device), session)
        this.log.info('relay: phone session opened', {
          peer: local.identity.id,
          device: record.device,
          display: record.display,
        })
      }
      this.ports.publish(
        inboxSubject(record.device, local.identity.id),
        utf8(JSON.stringify(reply)),
      )
    } catch (err) {
      this.log.warn('relay: handshake refused', {
        from: record.device,
        code: err instanceof ProtocolError ? err.code : String(err),
      })
    }
  }

  private async command(
    local: LocalPeer,
    record: DeviceRecord,
    session: Session,
    id: string,
    cmd: string,
    args: unknown,
  ): Promise<void> {
    let reply: Payload
    try {
      // The pairing again, right before acting: a revocation between frames wins.
      if (!(await this.paired(local, record.device)))
        throw new RefusalError('this phone is no longer paired')
      // The phone asks whether the peer is still there: the host answers, nothing runs.
      if (cmd === 'ping') {
        this.send(record.device, local.identity.id, session, {
          kind: 'reply',
          id,
          ok: true,
          result: { ok: true },
        })
        return
      }
      const result = await this.ports.exec(record, cmd, args)
      reply =
        typeof result === 'object' && result !== null && 'ok' in result
          ? { kind: 'reply', id, ok: true, result }
          : {
              kind: 'reply',
              id,
              ok: false,
              error: {
                code: 'unsupported',
                message: 'this answer does not travel to the phone yet',
              },
            }
    } catch (err) {
      const refused = err instanceof RefusalError
      reply = {
        kind: 'reply',
        id,
        ok: false,
        error: {
          code: refused ? 'refused' : 'internal',
          message: refused ? err.message : 'internal error',
        },
      }
    }
    try {
      this.send(record.device, local.identity.id, session, reply)
    } catch (err) {
      const tooLarge = err instanceof ProtocolError && err.code === 'too-large'
      this.log.warn('relay: answer not sent', { device: record.device, cmd, err: String(err) })
      const fallback: Payload = {
        kind: 'reply',
        id,
        ok: false,
        error: {
          code: tooLarge ? 'too-large' : 'internal',
          message: tooLarge ? 'the answer is too large for the phone' : 'internal error',
        },
      }
      this.send(record.device, local.identity.id, session, fallback)
    }
  }
}

/** The viewer as a device record: a grant with no person, so `exec` can keep it to share commands. */
function viewerRecord(peer: string, card: PeerCard): DeviceRecord {
  return {
    peer,
    device: card.id,
    dh: card.dh,
    display: 'buff.systems',
    pairId: '',
    created: 0,
    login: '',
    org: null,
    viewer: true,
  }
}
