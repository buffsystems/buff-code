// Protocol versioning: every peer announces the range it speaks in the handshake; the responder picks
// the highest common version or answers «incompatible», which the phone shows as its own screen.

export const PROTOCOL_VERSION = 1

export interface VersionRange {
  readonly min: number
  readonly max: number
}

export const SUPPORTED_VERSIONS: VersionRange = { min: 1, max: PROTOCOL_VERSION }

export function negotiateVersion(local: VersionRange, remote: VersionRange): number | null {
  const v = Math.min(local.max, remote.max)
  return v >= Math.max(local.min, remote.min) ? v : null
}
