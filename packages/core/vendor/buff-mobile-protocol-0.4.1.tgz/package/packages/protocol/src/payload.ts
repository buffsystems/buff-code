// What travels inside an envelope. For cabinet installs `cmd`/`args` are the cabinet's existing bus
// commands; for Buff Code — the commands of its mobile API (#639). Files go in chunks (files.ts).
// Every inbound payload passes parsePayload: a peer is authenticated, but its input is still input.

import { decodeJson, encodeJson } from './encoding.ts'
import { fail } from './errors.ts'

export interface CommandPayload {
  readonly kind: 'cmd'
  readonly id: string
  readonly cmd: string
  readonly args: unknown
}

export interface ReplyError {
  readonly code: string
  readonly message: string
}

export type ReplyPayload =
  | { readonly kind: 'reply'; readonly id: string; readonly ok: true; readonly result: unknown }
  | { readonly kind: 'reply'; readonly id: string; readonly ok: false; readonly error: ReplyError }

export interface EventPayload {
  readonly kind: 'event'
  readonly stream: string
  readonly record: unknown
}

export interface FileOffer {
  readonly kind: 'file.offer'
  readonly id: string
  readonly name: string
  readonly size: number
  readonly mime: string
  readonly sha256: string
  /** Per-file chunk key (base64url, 32 bytes); it never leaves the E2E channel. */
  readonly key: string
}

export interface FileChunk {
  readonly kind: 'file.chunk'
  readonly id: string
  readonly idx: number
  readonly ct: string
}

/** Receiver → sender: chunks still missing (after a reconnect, or after file.done). */
export interface FileNeed {
  readonly kind: 'file.need'
  readonly id: string
  readonly missing: readonly number[]
}

export interface FileDone {
  readonly kind: 'file.done'
  readonly id: string
}

export interface FileAck {
  readonly kind: 'file.ack'
  readonly id: string
}

export interface FileReject {
  readonly kind: 'file.reject'
  readonly id: string
  readonly code: string
}

export type FilePayload = FileOffer | FileChunk | FileNeed | FileDone | FileAck | FileReject

export type Payload = CommandPayload | ReplyPayload | EventPayload | FilePayload

const ID = /^[A-Za-z0-9_-]{1,64}$/
const NAME = /^[a-z][a-z0-9_.:-]{0,127}$/i

export function encodePayload(payload: Payload): Uint8Array {
  return encodeJson(payload)
}

export function decodePayload(bytes: Uint8Array): Payload {
  return parsePayload(decodeJson(bytes))
}

export function parsePayload(value: unknown): Payload {
  const p = record(value)
  switch (p.kind) {
    case 'cmd':
      return { kind: 'cmd', id: id(p.id), cmd: name(p.cmd), args: p.args ?? null }
    case 'reply':
      if (p.ok === true) return { kind: 'reply', id: id(p.id), ok: true, result: p.result ?? null }
      if (p.ok === false)
        return { kind: 'reply', id: id(p.id), ok: false, error: replyError(p.error) }
      return fail('bad-message', 'reply.ok')
    case 'event':
      return { kind: 'event', stream: name(p.stream), record: p.record ?? null }
    case 'file.offer':
      return {
        kind: 'file.offer',
        id: id(p.id),
        name: fileName(p.name),
        size: count(p.size),
        mime: text(p.mime, 255),
        sha256: text(p.sha256, 43),
        key: text(p.key, 43),
      }
    case 'file.chunk':
      return { kind: 'file.chunk', id: id(p.id), idx: count(p.idx), ct: text(p.ct, 256 * 1024) }
    case 'file.need':
      if (!Array.isArray(p.missing) || p.missing.length > 1024) fail('bad-message', 'file.need')
      return { kind: 'file.need', id: id(p.id), missing: p.missing.map(count) }
    case 'file.done':
    case 'file.ack':
      return { kind: p.kind, id: id(p.id) }
    case 'file.reject':
      return { kind: 'file.reject', id: id(p.id), code: name(p.code) }
    default:
      return fail('bad-message', 'unknown payload kind')
  }
}

function record(value: unknown): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value))
    fail('bad-message', 'not an object')
  return value as Record<string, unknown>
}

function id(value: unknown): string {
  return typeof value === 'string' && ID.test(value) ? value : fail('bad-message', 'id')
}

function name(value: unknown): string {
  return typeof value === 'string' && NAME.test(value) ? value : fail('bad-message', 'name')
}

function text(value: unknown, max: number): string {
  return typeof value === 'string' && value.length <= max
    ? value
    : fail('bad-message', 'text field')
}

function count(value: unknown): number {
  return Number.isSafeInteger(value) && (value as number) >= 0
    ? (value as number)
    : fail('bad-message', 'count')
}

function replyError(value: unknown): ReplyError {
  const e = record(value)
  return { code: name(e.code), message: text(e.message, 4096) }
}

/** A bare file name: no path, no control characters — the receiver may write it to disk. */
function fileName(value: unknown): string {
  const ok =
    typeof value === 'string' &&
    value.length > 0 &&
    value.length <= 255 &&
    value !== '.' &&
    value !== '..' &&
    ![...value].some((c) => c < ' ' || c === '\u007f' || c === '/' || c === '\\')
  return ok ? (value as string) : fail('bad-message', 'file name')
}
