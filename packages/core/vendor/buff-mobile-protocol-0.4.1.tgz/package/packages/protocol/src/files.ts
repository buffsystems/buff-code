// File transfer inside the E2E channel: file.offer → file.chunk… → file.done, the receiver answers
// file.ack or file.need (missing chunk indexes), which also drives resume after a reconnect —
// receiver state does not depend on the session. Each chunk is additionally sealed with a per-file
// key (sent in the offer) and AAD id‖idx, so a chunk cannot be moved to another file or position;
// the whole file is checked against its SHA-256 at the end.

import { xchacha20poly1305 } from '@noble/ciphers/chacha.js'
import { sha256 } from '@noble/hashes/sha2.js'
import {
  b64u,
  concat,
  encodeJson,
  equalBytes,
  fromB64u,
  fromB64uLength,
  u64be,
} from './encoding.ts'
import { fail } from './errors.ts'
import type { FileChunk, FileOffer } from './payload.ts'
import { type Random, systemRandom } from './random.ts'

export const FILE_CHUNK_BYTES = 128 * 1024

export interface FileSender {
  readonly offer: FileOffer
  readonly chunkCount: number
  chunk(idx: number): FileChunk
}

export interface FileReceiver {
  readonly offer: FileOffer
  /** Store one chunk; duplicates are ignored. */
  accept(chunk: FileChunk): void
  missing(): number[]
  /** The verified file; throws file-corrupt if the hash does not match. */
  complete(): Uint8Array
}

export interface OutgoingFile {
  readonly name: string
  readonly mime: string
  readonly data: Uint8Array
}

export function chunkCount(size: number): number {
  return Math.ceil(size / FILE_CHUNK_BYTES)
}

export function createFileSender(file: OutgoingFile, random: Random = systemRandom): FileSender {
  const key = random(32)
  const offer: FileOffer = {
    kind: 'file.offer',
    id: b64u(random(16)),
    name: file.name,
    size: file.data.length,
    mime: file.mime,
    sha256: b64u(sha256(file.data)),
    key: b64u(key),
  }
  const count = chunkCount(file.data.length)
  return {
    offer,
    chunkCount: count,
    chunk(idx) {
      if (!Number.isSafeInteger(idx) || idx < 0 || idx >= count)
        fail('bad-message', `no chunk ${idx}`)
      const plain = file.data.subarray(idx * FILE_CHUNK_BYTES, (idx + 1) * FILE_CHUNK_BYTES)
      const ct = xchacha20poly1305(key, chunkNonce(idx), chunkAad(offer.id, idx)).encrypt(plain)
      return { kind: 'file.chunk', id: offer.id, idx, ct: b64u(ct) }
    },
  }
}

/** Throws file-rejected when the offer exceeds the limit this side announced in the handshake. */
export function createFileReceiver(offer: FileOffer, maxBytes: number): FileReceiver {
  if (offer.size > maxBytes) fail('file-rejected', `file of ${offer.size} bytes over ${maxBytes}`)
  const key = fromB64uLength(offer.key, 32)
  const expected = fromB64uLength(offer.sha256, 32)
  const count = chunkCount(offer.size)
  const chunks = new Map<number, Uint8Array>()

  return {
    offer,
    accept(chunk) {
      if (chunk.id !== offer.id || chunk.idx >= count)
        fail('bad-message', `chunk ${chunk.idx} of ${chunk.id}`)
      if (chunks.has(chunk.idx)) return
      let plain: Uint8Array
      try {
        plain = xchacha20poly1305(
          key,
          chunkNonce(chunk.idx),
          chunkAad(offer.id, chunk.idx),
        ).decrypt(fromB64u(chunk.ct))
      } catch {
        return fail('decrypt-failed', `chunk ${chunk.idx}`)
      }
      const size = Math.min(FILE_CHUNK_BYTES, offer.size - chunk.idx * FILE_CHUNK_BYTES)
      if (plain.length !== size)
        fail('file-corrupt', `chunk ${chunk.idx} has ${plain.length} bytes`)
      chunks.set(chunk.idx, plain)
    },
    missing() {
      return Array.from({ length: count }, (_, i) => i).filter((i) => !chunks.has(i))
    },
    complete() {
      if (chunks.size !== count) fail('file-corrupt', `${count - chunks.size} chunks missing`)
      const data = concat(...Array.from({ length: count }, (_, i) => chunks.get(i)!))
      if (!equalBytes(sha256(data), expected)) fail('file-corrupt', 'sha256 mismatch')
      return data
    },
  }
}

function chunkNonce(idx: number): Uint8Array {
  return concat(new Uint8Array(16), u64be(idx))
}

function chunkAad(id: string, idx: number): Uint8Array {
  return encodeJson(['buff-file', id, idx])
}
